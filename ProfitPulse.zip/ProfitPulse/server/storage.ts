import { transactions, categories, employees, projects, type Transaction, type InsertTransaction, type Category, type InsertCategory, type Employee, type InsertEmployee, type Project, type InsertProject } from "@shared/schema";

export interface IStorage {
  // Transactions
  getTransactions(): Promise<Transaction[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: number): Promise<boolean>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  toggleCategoryDashboard(id: number, showOnDashboard: boolean): Promise<Category | undefined>;

  // Employees
  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<InsertEmployee>): Promise<Employee | undefined>;
  deleteEmployee(id: number): Promise<boolean>;

  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  toggleProjectDashboard(id: number, showOnDashboard: boolean): Promise<Project | undefined>;
}

export class MemStorage implements IStorage {
  private transactions: Map<number, Transaction>;
  private categories: Map<number, Category>;
  private employees: Map<number, Employee>;
  private projects: Map<number, Project>;
  private currentTransactionId: number;
  private currentCategoryId: number;
  private currentEmployeeId: number;
  private currentProjectId: number;

  constructor() {
    this.transactions = new Map();
    this.categories = new Map();
    this.employees = new Map();
    this.projects = new Map();
    this.currentTransactionId = 1;
    this.currentCategoryId = 1;
    this.currentEmployeeId = 1;
    this.currentProjectId = 1;
    
    // Initialize with default categories
    this.initializeDefaultCategories();
  }

  private initializeDefaultCategories() {
    const now = new Date();
    const defaultCategories: Omit<Category, 'id'>[] = [
      // Revenue Categories from your image
      { name: "Consulting, Factory & Engineering Revenue", type: "income", color: "#059669", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Gross Project Rent", type: "income", color: "#10B981", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "DPS Industrial Revenue", type: "income", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Power Revenue", type: "income", color: "#34D399", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Renewable Incentives / Tax Credits", type: "income", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Equity Sales of SPV Projects", type: "income", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Revenue from Partnerships", type: "income", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "CO2 Pipeline & Credit Sales", type: "income", color: "#84CC16", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Management & Performance Fees", type: "income", color: "#06B6D4", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Lithium Site Revenue", type: "income", color: "#8B5CF6", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Other Revenue", type: "income", color: "#F59E0B", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      
      // Expense Categories from your images
      { name: "Project Development Expenses", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Project Operating Expenses", type: "expense", color: "#EF4444", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Power Generation Expenses", type: "expense", color: "#F87171", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Vacancy / Bad Debt", type: "expense", color: "#FCA5A5", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Other Direct Expenses", type: "expense", color: "#7C3AED", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      
      // Additional Expense Categories from new image
      { name: "Contractor", type: "expense", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Healthcare", type: "expense", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Comp", type: "expense", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Expenses", type: "expense", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Bookkeeping", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Marketing & Fees", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Contractors", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Benefits", type: "expense", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Inclusive", type: "expense", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Professional", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Supplies & Wages", type: "expense", color: "#FBBF24", isActive: true, showOnDashboard: true, createdAt: now, updatedAt: now },
      { name: "Licenses", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Travel", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Miscellaneous", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      
      // Additional Income Categories from new image
      { name: "Total SG&A", type: "income", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Other Income", type: "income", color: "#059669", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Miscellaneous Income", type: "income", color: "#059669", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Expenses", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Gain or Loss", type: "income", color: "#059669", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
      { name: "Expenses", type: "expense", color: "#DC2626", isActive: true, showOnDashboard: false, createdAt: now, updatedAt: now },
    ];

    defaultCategories.forEach(category => {
      const id = this.currentCategoryId++;
      this.categories.set(id, { ...category, id });
    });
  }

  // Transaction methods
  async getTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      createdAt: new Date(),
      notes: insertTransaction.notes || null,
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransaction(id: number, updateData: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    const existingTransaction = this.transactions.get(id);
    if (!existingTransaction) {
      return undefined;
    }

    const updatedTransaction: Transaction = {
      ...existingTransaction,
      ...updateData,
    };
    this.transactions.set(id, updatedTransaction);
    return updatedTransaction;
  }

  async deleteTransaction(id: number): Promise<boolean> {
    return this.transactions.delete(id);
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = {
      ...insertCategory,
      id,
    };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: number, updateData: Partial<InsertCategory>): Promise<Category | undefined> {
    const existingCategory = this.categories.get(id);
    if (!existingCategory) {
      return undefined;
    }

    const updatedCategory: Category = {
      ...existingCategory,
      ...updateData,
    };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }

  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }

  async toggleCategoryDashboard(id: number, showOnDashboard: boolean): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updatedCategory: Category = {
      ...category,
      showOnDashboard,
      updatedAt: new Date(),
    };
    
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }

  // Employee methods
  async getEmployees(): Promise<Employee[]> {
    return Array.from(this.employees.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    return this.employees.get(id);
  }

  async createEmployee(insertEmployee: InsertEmployee): Promise<Employee> {
    const id = this.currentEmployeeId++;
    const employee: Employee = {
      ...insertEmployee,
      id,
      createdAt: new Date(),
      position: insertEmployee.position || null,
      assignedSpv: insertEmployee.assignedSpv || null,
      isActive: insertEmployee.isActive || "true",
    };
    this.employees.set(id, employee);
    return employee;
  }

  async updateEmployee(id: number, updateData: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const existingEmployee = this.employees.get(id);
    if (!existingEmployee) {
      return undefined;
    }

    const updatedEmployee: Employee = {
      ...existingEmployee,
      ...updateData,
    };
    this.employees.set(id, updatedEmployee);
    return updatedEmployee;
  }

  async deleteEmployee(id: number): Promise<boolean> {
    return this.employees.delete(id);
  }

  // Project methods
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const now = new Date();
    const project: Project = {
      name: insertProject.name,
      description: insertProject.description ?? null,
      projectType: insertProject.projectType ?? "mining",
      timelineYears: insertProject.timelineYears ?? 20,
      startYear: insertProject.startYear ?? 2024,
      currency: insertProject.currency ?? "USD",
      isActive: insertProject.isActive ?? true,
      showOnDashboard: insertProject.showOnDashboard ?? false,
      initialRevenue: insertProject.initialRevenue,
      peakRevenue: insertProject.peakRevenue,
      initialOpexRate: insertProject.initialOpexRate,
      matureOpexRate: insertProject.matureOpexRate,
      initialCapex: insertProject.initialCapex,
      maintenanceCapex: insertProject.maintenanceCapex,
      loanAmount: insertProject.loanAmount ?? "0",
      interestRate: insertProject.interestRate ?? "0.05",
      loanTermYears: insertProject.loanTermYears ?? 10,
      paymentFrequency: insertProject.paymentFrequency ?? "Annual",
      gracePeriod: insertProject.gracePeriod ?? 0,
      assetCost: insertProject.assetCost ?? "0",
      depreciationMethod: insertProject.depreciationMethod ?? "Straight-line",
      depreciationYears: insertProject.depreciationYears ?? 10,
      salvageValue: insertProject.salvageValue ?? "0",
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const existingProject = this.projects.get(id);
    if (!existingProject) {
      return undefined;
    }

    const updatedProject: Project = {
      ...existingProject,
      ...updateData,
      updatedAt: new Date(),
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  async toggleProjectDashboard(id: number, showOnDashboard: boolean): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) {
      return undefined;
    }

    const updatedProject: Project = {
      ...project,
      showOnDashboard,
      updatedAt: new Date(),
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
}

export const storage = new MemStorage();
