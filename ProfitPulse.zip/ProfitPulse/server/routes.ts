import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import * as XLSX from "xlsx";
import { storage } from "./storage";
import { insertTransactionSchema, insertCategorySchema, insertEmployeeSchema, insertProjectSchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  fileFilter: (req, file, cb) => {
    const allowedMimeTypes = [
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv'
    ];
    if (allowedMimeTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only Excel and CSV files are allowed'));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Transaction routes
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactions();
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.get("/api/transactions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid transaction ID" });
      }

      const transaction = await storage.getTransaction(id);
      if (!transaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }

      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transaction" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(validatedData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid transaction data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  app.put("/api/transactions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid transaction ID" });
      }

      const validatedData = insertTransactionSchema.partial().parse(req.body);
      const transaction = await storage.updateTransaction(id, validatedData);
      
      if (!transaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }

      res.json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid transaction data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update transaction" });
    }
  });

  app.delete("/api/transactions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid transaction ID" });
      }

      const deleted = await storage.deleteTransaction(id);
      if (!deleted) {
        return res.status(404).json({ message: "Transaction not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete transaction" });
    }
  });

  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    try {
      const validatedData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(validatedData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid category data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.patch("/api/categories/:id/dashboard", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }

      const { showOnDashboard } = req.body;
      if (typeof showOnDashboard !== 'boolean') {
        return res.status(400).json({ message: "showOnDashboard must be a boolean" });
      }

      const category = await storage.toggleCategoryDashboard(id, showOnDashboard);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }

      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to update category dashboard setting" });
    }
  });

  // Employee routes
  app.get("/api/employees", async (req, res) => {
    try {
      const employees = await storage.getEmployees();
      res.json(employees);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  app.post("/api/employees", async (req, res) => {
    try {
      const validatedData = insertEmployeeSchema.parse(req.body);
      const employee = await storage.createEmployee(validatedData);
      
      // Automatically create salary expense transactions
      const monthlySalary = parseFloat(employee.salary) / 12;
      const startDate = new Date(employee.startDate);
      const currentDate = new Date();
      
      // Add salary transactions from start date to current month
      const monthsToAdd = [];
      let currentMonth = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
      
      while (currentMonth <= currentDate) {
        monthsToAdd.push(new Date(currentMonth));
        currentMonth.setMonth(currentMonth.getMonth() + 1);
      }
      
      for (const month of monthsToAdd) {
        try {
          await storage.createTransaction({
            description: `Salary - ${employee.name}`,
            amount: monthlySalary.toFixed(2),
            type: "expense" as const,
            category: "Payroll",
            date: month.toISOString().split('T')[0],
            notes: `Auto-generated from employee record`,
          });
        } catch (error) {
          console.error(`Failed to create salary transaction for ${employee.name}:`, error);
        }
      }
      
      res.status(201).json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid employee data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create employee" });
    }
  });

  app.put("/api/employees/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid employee ID" });
      }

      const validatedData = insertEmployeeSchema.partial().parse(req.body);
      const employee = await storage.updateEmployee(id, validatedData);
      
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }

      res.json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid employee data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update employee" });
    }
  });

  app.delete("/api/employees/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid employee ID" });
      }

      const deleted = await storage.deleteEmployee(id);
      if (!deleted) {
        return res.status(404).json({ message: "Employee not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete employee" });
    }
  });

  // Financial summary endpoint
  app.get("/api/financial-summary", async (req, res) => {
    try {
      const transactions = await storage.getTransactions();
      const employees = await storage.getEmployees();
      
      const totalRevenue = transactions
        .filter(t => t.type === "income")
        .reduce((sum, t) => sum + parseFloat(t.amount), 0);
      
      const totalExpenses = transactions
        .filter(t => t.type === "expense")
        .reduce((sum, t) => sum + parseFloat(t.amount), 0);
      
      const netProfit = totalRevenue - totalExpenses;
      const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

      // Calculate monthly trends (last 6 months)
      const now = new Date();
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(now.getMonth() - 6);

      const monthlyData = [];
      for (let i = 5; i >= 0; i--) {
        const month = new Date();
        month.setMonth(now.getMonth() - i);
        const monthStr = month.toISOString().slice(0, 7); // YYYY-MM format

        const monthTransactions = transactions.filter(t => 
          t.date.startsWith(monthStr)
        );

        const monthRevenue = monthTransactions
          .filter(t => t.type === "income")
          .reduce((sum, t) => sum + parseFloat(t.amount), 0);

        const monthExpenses = monthTransactions
          .filter(t => t.type === "expense")
          .reduce((sum, t) => sum + parseFloat(t.amount), 0);

        monthlyData.push({
          month: month.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
          revenue: monthRevenue,
          expenses: monthExpenses,
          profit: monthRevenue - monthExpenses
        });
      }

      // Calculate category breakdown
      const categories = await storage.getCategories();
      const categoryTotals = categories.map(category => {
        const categoryTransactions = transactions.filter(t => t.category === category.name);
        const total = categoryTransactions.reduce((sum, t) => sum + parseFloat(t.amount), 0);
        const percentage = totalExpenses > 0 && category.type === "expense" 
          ? (total / totalExpenses) * 100 
          : totalRevenue > 0 && category.type === "income"
          ? (total / totalRevenue) * 100
          : 0;

        return {
          ...category,
          total,
          percentage
        };
      }).filter(c => c.total > 0);

      res.json({
        totalRevenue,
        totalExpenses,
        netProfit,
        profitMargin,
        monthlyData,
        categoryBreakdown: categoryTotals
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate financial summary" });
    }
  });

  // Excel upload endpoint
  app.post("/api/upload-excel", upload.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);

      const categories = await storage.getCategories();
      const categoryMap = new Map(categories.map(c => [c.name.toLowerCase(), c.id]));
      
      let processedCount = 0;
      let errorCount = 0;
      const errors: string[] = [];

      for (let index = 0; index < data.length; index++) {
        const row = data[index];
        try {
          const rowData = row as any;
          
          // Extract data from common Excel column names
          const description = rowData.Description || rowData.description || 
                            rowData.DESCRIPTION || rowData.Note || rowData.note || 
                            rowData.Memo || rowData.memo || `Transaction ${index + 1}`;
          
          const amount = parseFloat(
            String(rowData.Amount || rowData.amount || rowData.AMOUNT || 
                   rowData.Value || rowData.value || rowData.Price || rowData.price || 0)
              .replace(/[,$]/g, '')
          );
          
          const type = String(rowData.Type || rowData.type || rowData.TYPE || 
                              rowData.Category || rowData.category || 'expense')
                        .toLowerCase();
          
          const date = rowData.Date || rowData.date || rowData.DATE || 
                       rowData.TransactionDate || rowData.transaction_date || new Date().toISOString().split('T')[0];
          
          const categoryName = String(rowData.Category || rowData.category || 
                                    rowData.CATEGORY || 'Other').toLowerCase();

          if (amount <= 0) {
            errors.push(`Row ${index + 1}: Invalid amount (${amount})`);
            errorCount++;
            continue;
          }

          // Determine transaction type
          let transactionType: 'income' | 'expense' = 'expense';
          if (type.includes('income') || type.includes('revenue') || type.includes('credit')) {
            transactionType = 'income';
          }

          // Find or create category
          let categoryName_formatted = categoryName.charAt(0).toUpperCase() + categoryName.slice(1);
          let categoryId = categoryMap.get(categoryName);
          if (!categoryId) {
            // Create new category if it doesn't exist
            const newCategory = await storage.createCategory({
              name: categoryName_formatted,
              type: transactionType,
              color: transactionType === 'income' ? '#10b981' : '#ef4444'
            });
            categoryId = newCategory.id;
            categoryMap.set(categoryName, categoryId);
          }

          // Create transaction
          const transaction = await storage.createTransaction({
            description,
            amount: amount.toString(),
            type: transactionType,
            category: categoryName_formatted,
            date
          });

          processedCount++;
        } catch (error) {
          errorCount++;
          errors.push(`Row ${index + 1}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }

      res.json({
        message: `Successfully processed ${processedCount} transactions`,
        processedCount,
        errorCount,
        errors: errors.slice(0, 10) // Limit to first 10 errors
      });

    } catch (error) {
      console.error('Excel upload error:', error);
      res.status(500).json({ 
        message: "Failed to process Excel file",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid project data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(id, validatedData);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid project data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.patch("/api/projects/:id/dashboard", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { showOnDashboard } = req.body;
      
      if (typeof showOnDashboard !== 'boolean') {
        return res.status(400).json({ message: "showOnDashboard must be a boolean" });
      }

      const project = await storage.toggleProjectDashboard(id, showOnDashboard);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to update project dashboard setting" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProject(id);
      
      if (!success) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Reset data endpoint
  app.post("/api/reset", async (req, res) => {
    try {
      // Clear all data from storage
      const storage_instance = storage as any;
      storage_instance.transactions.clear();
      storage_instance.employees.clear();
      storage_instance.projects.clear();
      storage_instance.currentTransactionId = 1;
      storage_instance.currentEmployeeId = 1;
      storage_instance.currentProjectId = 1;
      
      res.json({ message: "All data has been reset successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to reset data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
