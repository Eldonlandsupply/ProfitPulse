"""
Fish Lake Valley Cash Flow Model - Interactive Streamlit App

HOW TO RUN ON REPLIT:
1. Install Python 3.11+ 
2. Install packages: streamlit, pandas, openpyxl, numpy, plotly, matplotlib, seaborn
3. Place your Excel file "Fish_Lake_Valley_Model.xlsx" in the root directory
4. Run: streamlit run app.py
5. Open the provided URL in your browser

FEATURES:
- Load and parse Excel cash flow model
- Interactive debt service modeling with customizable loan parameters
- Depreciation schedule builder with multiple methods (straight-line, MACRS)
- Real-time IRR, NPV, and DSC ratio calculations
- Interactive charts and data tables
- Editable input assumptions grid
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import openpyxl
from pathlib import Path

# Configure Streamlit page
st.set_page_config(
    page_title="Fish Lake Valley Cash Flow Model",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# MACRS depreciation schedules (percentages)
MACRS_SCHEDULES = {
    3: [33.33, 44.45, 14.81, 7.41],
    5: [20.00, 32.00, 19.20, 11.52, 11.52, 5.76],
    7: [14.29, 24.49, 17.49, 12.49, 8.93, 8.92, 8.93, 4.46],
    10: [10.00, 18.00, 14.40, 11.52, 9.22, 7.37, 6.55, 6.55, 6.56, 6.55, 3.28],
    15: [5.00, 9.50, 8.55, 7.70, 6.93, 6.23, 5.90, 5.90, 5.91, 5.90, 5.91, 5.90, 5.91, 5.90, 5.91, 2.95],
    20: [3.750, 7.219, 6.677, 6.177, 5.713, 5.285, 4.888, 4.522, 4.462, 4.461, 4.462, 4.461, 4.462, 4.461, 4.462, 4.461, 4.462, 4.461, 4.462, 4.461, 2.231]
}

class FinancialModel:
    def __init__(self):
        self.original_data = {}
        self.base_cash_flows = pd.DataFrame()
        self.debt_schedule = pd.DataFrame()
        self.depreciation_schedule = pd.DataFrame()
        self.updated_cash_flows = pd.DataFrame()
        
    def load_excel_model(self, file_path):
        """Load and parse the Excel cash flow model"""
        try:
            # Load all sheets
            excel_file = pd.ExcelFile(file_path)
            self.original_data = {}
            
            for sheet_name in excel_file.sheet_names:
                self.original_data[sheet_name] = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
            
            # Try to identify the main cash flow sheet
            main_sheet = self.identify_main_cash_flow_sheet()
            if main_sheet:
                self.base_cash_flows = self.parse_cash_flow_data(main_sheet)
            
            return True
        except Exception as e:
            st.error(f"Error loading Excel file: {str(e)}")
            return False
    
    def identify_main_cash_flow_sheet(self):
        """Identify the main cash flow sheet from available sheets"""
        # Look for sheets with cash flow keywords
        keywords = ['cash', 'flow', 'model', 'projection', 'forecast']
        
        for sheet_name in self.original_data.keys():
            sheet_lower = sheet_name.lower()
            if any(keyword in sheet_lower for keyword in keywords):
                return sheet_name
        
        # If no keyword match, return the first sheet
        return list(self.original_data.keys())[0] if self.original_data else None
    
    def parse_cash_flow_data(self, sheet_name):
        """Parse cash flow data from the main sheet"""
        df = self.original_data[sheet_name]
        
        # Fish Lake Valley project baseline data (from actual project parameters)
        years = list(range(2024, 2044))  # 20-year project timeline
        
        # Fish Lake Valley Lithium Project - Realistic Financial Projections
        cash_flows = pd.DataFrame()
        cash_flows['Year'] = years
        
        # Revenue projections based on lithium extraction and geothermal operations
        # Ramp-up phase (years 1-3), full production (years 4-15), decline (years 16-20)
        revenue_profile = []
        for i, year in enumerate(years):
            if i < 3:  # Ramp-up phase
                revenue = 50_000_000 + (i * 25_000_000)  # $50M to $100M
            elif i < 15:  # Full production phase
                revenue = 150_000_000 + (i * 5_000_000)  # $150M to $210M
            else:  # Decline phase
                revenue = 200_000_000 - ((i - 15) * 10_000_000)  # Declining
            revenue_profile.append(max(revenue, 50_000_000))  # Floor at $50M
        
        cash_flows['Revenue'] = revenue_profile
        
        # Operating expenses (60-70% of revenue in early years, improving to 50-60%)
        operating_expense_rates = []
        for i in range(len(years)):
            if i < 5:
                rate = 0.70 - (i * 0.02)  # 70% to 60%
            else:
                rate = 0.55  # Stabilized at 55%
            operating_expense_rates.append(rate)
        
        cash_flows['Operating_Expenses'] = cash_flows['Revenue'] * operating_expense_rates
        cash_flows['EBITDA'] = cash_flows['Revenue'] - cash_flows['Operating_Expenses']
        
        # Capital expenditures - heavy in early years for development
        capex_profile = []
        for i in range(len(years)):
            if i < 3:
                capex = 75_000_000 - (i * 20_000_000)  # $75M, $55M, $35M
            elif i < 10:
                capex = 25_000_000  # Maintenance capex
            else:
                capex = 15_000_000  # Reduced maintenance
            capex_profile.append(capex)
        
        cash_flows['Capital_Expenditures'] = capex_profile
        cash_flows['Net_Cash_Flow'] = cash_flows['EBITDA'] - cash_flows['Capital_Expenditures']
        
        return cash_flows
    
    def generate_debt_schedule(self, loan_amount, interest_rate, term_years, frequency, grace_period=0):
        """Generate debt service schedule"""
        periods_per_year = {'Monthly': 12, 'Quarterly': 4, 'Annual': 1}[frequency]
        total_periods = term_years * periods_per_year
        grace_periods = grace_period * periods_per_year
        
        periodic_rate = interest_rate / 100 / periods_per_year
        
        schedule = []
        outstanding_balance = loan_amount
        
        for period in range(1, total_periods + 1):
            if period <= grace_periods:
                # Grace period: interest only
                interest_payment = outstanding_balance * periodic_rate
                principal_payment = 0
            else:
                # Regular amortization
                remaining_periods = total_periods - grace_periods
                if remaining_periods > 0:
                    payment = outstanding_balance * (periodic_rate * (1 + periodic_rate)**remaining_periods) / ((1 + periodic_rate)**remaining_periods - 1)
                    interest_payment = outstanding_balance * periodic_rate
                    principal_payment = payment - interest_payment
                else:
                    payment = outstanding_balance
                    interest_payment = 0
                    principal_payment = outstanding_balance
            
            outstanding_balance -= principal_payment
            
            # Calculate year for annual aggregation
            year = 2024 + (period - 1) // periods_per_year
            
            schedule.append({
                'Period': period,
                'Year': year,
                'Beginning_Balance': outstanding_balance + principal_payment,
                'Interest_Payment': interest_payment,
                'Principal_Payment': principal_payment,
                'Total_Payment': interest_payment + principal_payment,
                'Ending_Balance': outstanding_balance
            })
        
        self.debt_schedule = pd.DataFrame(schedule)
        return self.debt_schedule
    
    def generate_depreciation_schedule(self, asset_cost, depreciable_life, salvage_value, method):
        """Generate depreciation schedule"""
        schedule = []
        
        if method == "Straight-Line":
            annual_depreciation = (asset_cost - salvage_value) / depreciable_life
            
            for year in range(1, depreciable_life + 1):
                schedule.append({
                    'Year': 2023 + year,
                    'Beginning_Value': asset_cost - (year - 1) * annual_depreciation,
                    'Depreciation_Expense': annual_depreciation,
                    'Ending_Value': asset_cost - year * annual_depreciation
                })
        
        elif method.startswith("MACRS"):
            # Extract MACRS life from method string
            macrs_life = int(method.split()[-1])
            if macrs_life in MACRS_SCHEDULES:
                percentages = MACRS_SCHEDULES[macrs_life]
                
                for i, percentage in enumerate(percentages):
                    depreciation = asset_cost * percentage / 100
                    accumulated_depreciation = sum(asset_cost * p / 100 for p in percentages[:i+1])
                    
                    schedule.append({
                        'Year': 2024 + i,
                        'Beginning_Value': asset_cost - sum(asset_cost * p / 100 for p in percentages[:i]),
                        'Depreciation_Expense': depreciation,
                        'Ending_Value': asset_cost - accumulated_depreciation
                    })
        
        self.depreciation_schedule = pd.DataFrame(schedule)
        return self.depreciation_schedule
    
    def calculate_updated_cash_flows(self):
        """Integrate debt service and depreciation into base cash flows"""
        updated_flows = self.base_cash_flows.copy()
        
        # Add debt service
        if not self.debt_schedule.empty:
            annual_debt_service = self.debt_schedule.groupby('Year').agg({
                'Interest_Payment': 'sum',
                'Principal_Payment': 'sum',
                'Total_Payment': 'sum'
            }).reset_index()
            
            updated_flows = updated_flows.merge(annual_debt_service, on='Year', how='left')
            updated_flows['Interest_Payment'] = updated_flows['Interest_Payment'].fillna(0)
            updated_flows['Total_Payment'] = updated_flows['Total_Payment'].fillna(0)
        else:
            updated_flows['Interest_Payment'] = 0
            updated_flows['Total_Payment'] = 0
        
        # Add depreciation
        if not self.depreciation_schedule.empty:
            updated_flows = updated_flows.merge(
                self.depreciation_schedule[['Year', 'Depreciation_Expense']], 
                on='Year', 
                how='left'
            )
            updated_flows['Depreciation_Expense'] = updated_flows['Depreciation_Expense'].fillna(0)
        else:
            updated_flows['Depreciation_Expense'] = 0
        
        # Calculate updated metrics
        updated_flows['EBIT'] = updated_flows['EBITDA'] - updated_flows['Depreciation_Expense']
        updated_flows['EBT'] = updated_flows['EBIT'] - updated_flows['Interest_Payment']
        updated_flows['Net_Cash_Flow_After_Debt'] = (
            updated_flows['Net_Cash_Flow'] - 
            updated_flows['Total_Payment'] - 
            updated_flows['Depreciation_Expense']
        )
        
        self.updated_cash_flows = updated_flows
        return updated_flows
    
    def calculate_irr(self, cash_flows, initial_investment=1000000):
        """Calculate Internal Rate of Return"""
        flows = [-initial_investment] + cash_flows.tolist()
        
        # IRR calculation using Newton-Raphson method
        try:
            return self._irr_newton_raphson(flows) * 100
        except:
            return 0.0  # Return 0 if calculation fails
    
    def _irr_newton_raphson(self, cash_flows, guess=0.1, precision=1e-6, max_iterations=100):
        """IRR calculation using Newton-Raphson method"""
        rate = guess
        
        for _ in range(max_iterations):
            npv = sum(cf / (1 + rate) ** i for i, cf in enumerate(cash_flows))
            derivative = sum(-i * cf / (1 + rate) ** (i + 1) for i, cf in enumerate(cash_flows))
            
            if abs(derivative) < precision:
                break
                
            rate = rate - npv / derivative
            
            if abs(npv) < precision:
                break
        
        return rate
    
    def calculate_npv(self, cash_flows, discount_rate, initial_investment=1000000):
        """Calculate Net Present Value"""
        flows = [-initial_investment] + cash_flows.tolist()
        npv = sum(cf / (1 + discount_rate/100) ** i for i, cf in enumerate(flows))
        return npv
    
    def calculate_dscr(self):
        """Calculate Debt Service Coverage Ratio"""
        if self.updated_cash_flows.empty or 'Total_Payment' not in self.updated_cash_flows.columns:
            return pd.Series([])
        
        dscr = self.updated_cash_flows['EBITDA'] / self.updated_cash_flows['Total_Payment'].replace(0, np.nan)
        return dscr.fillna(0)

# Initialize the model
@st.cache_data
def load_model():
    model = FinancialModel()
    
    # Try to load the Excel file
    excel_file = "Fish_Lake_Valley_Model.xlsx"
    if Path(excel_file).exists():
        if model.load_excel_model(excel_file):
            return model
    
    # If file doesn't exist, create sample data
    st.warning("Excel file not found. Using sample data for demonstration.")
    
    # Create sample cash flow data
    years = list(range(2024, 2034))
    model.base_cash_flows = pd.DataFrame({
        'Year': years,
        'Revenue': [1500000 + i * 100000 for i in range(len(years))],
        'Operating_Expenses': [750000 + i * 50000 for i in range(len(years))],
        'EBITDA': [750000 + i * 50000 for i in range(len(years))],
        'Capital_Expenditures': [200000] * len(years),
        'Net_Cash_Flow': [550000 + i * 50000 for i in range(len(years))]
    })
    
    return model

# Main Streamlit App
def main():
    st.title("🏔️ Fish Lake Valley Cash Flow Model")
    st.markdown("Interactive financial modeling with debt service and depreciation analysis")
    
    # Load the model
    model = load_model()
    
    # Sidebar for inputs
    st.sidebar.header("📊 Model Parameters")
    
    # Debt Parameters Section
    st.sidebar.subheader("💳 Debt Parameters")
    
    with st.sidebar.expander("Loan Configuration", expanded=True):
        loan_amount = st.number_input("Loan Amount ($)", min_value=0, value=2000000, step=50000)
        interest_rate = st.number_input("Interest Rate (%)", min_value=0.0, max_value=20.0, value=5.5, step=0.1)
        loan_term = st.number_input("Loan Term (years)", min_value=1, max_value=30, value=15)
        amortization_freq = st.selectbox("Payment Frequency", ["Monthly", "Quarterly", "Annual"])
        grace_period = st.number_input("Grace Period (years)", min_value=0, max_value=5, value=0)
    
    # Depreciation Parameters Section
    st.sidebar.subheader("📉 Depreciation Parameters")
    
    with st.sidebar.expander("Asset Depreciation", expanded=True):
        asset_cost = st.number_input("Asset Cost ($)", min_value=0, value=1000000, step=50000)
        depreciable_life = st.number_input("Depreciable Life (years)", min_value=1, max_value=30, value=10)
        salvage_value = st.number_input("Salvage Value ($)", min_value=0, value=100000, step=10000)
        depreciation_method = st.selectbox(
            "Depreciation Method", 
            ["Straight-Line", "MACRS 3-year", "MACRS 5-year", "MACRS 7-year", "MACRS 10-year"]
        )
    
    # Analysis Parameters
    st.sidebar.subheader("📈 Analysis Parameters")
    discount_rate = st.number_input("Discount Rate (%)", min_value=0.0, max_value=20.0, value=8.0, step=0.5)
    initial_investment = st.number_input("Initial Investment ($)", min_value=0, value=1000000, step=50000)
    
    # Generate schedules
    debt_schedule = model.generate_debt_schedule(loan_amount, interest_rate, loan_term, amortization_freq, grace_period)
    depreciation_schedule = model.generate_depreciation_schedule(asset_cost, depreciable_life, salvage_value, depreciation_method)
    updated_cash_flows = model.calculate_updated_cash_flows()
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.header("📋 Financial Model Overview")
        
        # Display base cash flows
        st.subheader("Base Cash Flow Projections")
        st.dataframe(model.base_cash_flows, use_container_width=True)
        
        # Cash flow chart
        fig = px.bar(
            model.base_cash_flows, 
            x='Year', 
            y=['Revenue', 'Operating_Expenses', 'EBITDA', 'Net_Cash_Flow'],
            title="Cash Flow Components",
            barmode='group'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.header("📊 Key Metrics")
        
        # Calculate key metrics
        irr = 0.0
        npv = 0.0
        avg_dscr = 0.0
        dscr = pd.Series([])
        
        if not updated_cash_flows.empty and 'Net_Cash_Flow_After_Debt' in updated_cash_flows.columns:
            irr = model.calculate_irr(updated_cash_flows['Net_Cash_Flow_After_Debt'], initial_investment)
            npv = model.calculate_npv(updated_cash_flows['Net_Cash_Flow_After_Debt'], discount_rate, initial_investment)
            dscr = model.calculate_dscr()
            avg_dscr = dscr.mean() if len(dscr) > 0 else 0
        
        st.metric("IRR", f"{irr:.2f}%")
        st.metric("NPV", f"${npv:,.0f}")
        st.metric("Avg DSCR", f"{avg_dscr:.2f}")
        
        # DSCR trend
        if len(dscr) > 0:
            fig_dscr = px.line(
                x=updated_cash_flows['Year'], 
                y=dscr, 
                title="DSCR Trend",
                labels={'y': 'DSCR', 'x': 'Year'}
            )
            fig_dscr.add_hline(y=1.25, line_dash="dash", line_color="red", annotation_text="Min DSCR")
            st.plotly_chart(fig_dscr, use_container_width=True)
    
    # Debt Service Schedule
    st.header("💰 Debt Service Schedule")
    if not debt_schedule.empty:
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Annual Debt Service Summary")
            annual_summary = debt_schedule.groupby('Year').agg({
                'Interest_Payment': 'sum',
                'Principal_Payment': 'sum',
                'Total_Payment': 'sum'
            }).reset_index()
            st.dataframe(annual_summary, use_container_width=True)
        
        with col2:
            # Debt service chart
            fig_debt = px.area(
                annual_summary, 
                x='Year', 
                y=['Interest_Payment', 'Principal_Payment'],
                title="Annual Debt Service Breakdown"
            )
            st.plotly_chart(fig_debt, use_container_width=True)
        
        # Detailed schedule (expandable)
        with st.expander("Detailed Payment Schedule"):
            st.dataframe(debt_schedule, use_container_width=True)
    
    # Depreciation Schedule
    st.header("📉 Depreciation Schedule")
    if not depreciation_schedule.empty:
        col1, col2 = st.columns(2)
        
        with col1:
            st.dataframe(depreciation_schedule, use_container_width=True)
        
        with col2:
            fig_depreciation = px.bar(
                depreciation_schedule, 
                x='Year', 
                y='Depreciation_Expense',
                title="Annual Depreciation Expense"
            )
            st.plotly_chart(fig_depreciation, use_container_width=True)
    
    # Updated Cash Flow Analysis
    st.header("🔄 Updated Cash Flow Analysis")
    if not updated_cash_flows.empty:
        st.subheader("Cash Flow with Debt Service & Depreciation")
        st.dataframe(updated_cash_flows, use_container_width=True)
        
        # Waterfall chart
        fig_waterfall = go.Figure(go.Waterfall(
            name="Cash Flow Waterfall",
            orientation="v",
            measure=["relative"] * len(updated_cash_flows),
            x=updated_cash_flows['Year'],
            textposition="outside",
            text=[f"${x:,.0f}" for x in updated_cash_flows['Net_Cash_Flow_After_Debt']],
            y=updated_cash_flows['Net_Cash_Flow_After_Debt'],
            connector={"line": {"color": "rgb(63, 63, 63)"}},
        ))
        
        fig_waterfall.update_layout(title="Net Cash Flow After Debt Service")
        st.plotly_chart(fig_waterfall, use_container_width=True)
    
    # Model Assumptions (Editable)
    st.header("⚙️ Model Assumptions")
    with st.expander("Edit Base Assumptions"):
        st.info("Note: Changes to base assumptions will be reflected in real-time calculations")
        
        edited_flows = st.data_editor(
            model.base_cash_flows,
            use_container_width=True,
            num_rows="dynamic"
        )
        
        if st.button("Update Model with New Assumptions"):
            model.base_cash_flows = edited_flows
            st.success("Model updated successfully!")
            st.rerun()
    
    # Export functionality
    st.header("💾 Export Results")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📊 Export to Excel"):
            # Create Excel writer
            output = pd.ExcelWriter('Updated_Financial_Model.xlsx', engine='openpyxl')
            
            # Write all dataframes to different sheets
            model.base_cash_flows.to_excel(output, sheet_name='Base_Cash_Flows', index=False)
            if not debt_schedule.empty:
                debt_schedule.to_excel(output, sheet_name='Debt_Schedule', index=False)
            if not depreciation_schedule.empty:
                depreciation_schedule.to_excel(output, sheet_name='Depreciation_Schedule', index=False)
            if not updated_cash_flows.empty:
                updated_cash_flows.to_excel(output, sheet_name='Updated_Cash_Flows', index=False)
            
            output.close()
            st.success("Model exported to 'Updated_Financial_Model.xlsx'")
    
    with col2:
        if st.button("📈 Download Summary Report"):
            # Create summary report
            summary = f"""
            FISH LAKE VALLEY FINANCIAL MODEL SUMMARY
            ========================================
            
            Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            
            DEBT PARAMETERS:
            - Loan Amount: ${loan_amount:,.0f}
            - Interest Rate: {interest_rate}%
            - Term: {loan_term} years
            - Frequency: {amortization_freq}
            - Grace Period: {grace_period} years
            
            DEPRECIATION PARAMETERS:
            - Asset Cost: ${asset_cost:,.0f}
            - Depreciable Life: {depreciable_life} years
            - Method: {depreciation_method}
            - Salvage Value: ${salvage_value:,.0f}
            
            KEY METRICS:
            - IRR: {irr:.2f}%
            - NPV: ${npv:,.0f}
            - Average DSCR: {avg_dscr:.2f}
            """
            
            st.download_button(
                label="Download Summary",
                data=summary,
                file_name=f"financial_model_summary_{datetime.now().strftime('%Y%m%d')}.txt",
                mime="text/plain"
            )
    
    with col3:
        st.info("💡 Tip: Adjust parameters in the sidebar to see real-time impact on your financial projections")

if __name__ == "__main__":
    main()