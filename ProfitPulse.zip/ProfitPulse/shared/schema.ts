import { pgTable, text, serial, decimal, timestamp, integer, boolean, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  type: text("type", { enum: ["income", "expense"] }).notNull(),
  category: text("category").notNull(),
  date: text("date").notNull(), // ISO date string
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  type: text("type", { enum: ["income", "expense"] }).notNull(),
  color: text("color").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  showOnDashboard: boolean("show_on_dashboard").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  position: text("position"),
  assignedSpv: text("assigned_spv"),
  salary: decimal("salary", { precision: 10, scale: 2 }).notNull(),
  startDate: text("start_date").notNull(), // ISO date string
  isActive: text("is_active", { enum: ["true", "false"] }).notNull().default("true"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  projectType: text("project_type").default("mining").notNull(),
  timelineYears: integer("timeline_years").default(20).notNull(),
  startYear: integer("start_year").default(2024).notNull(),
  currency: text("currency").default("USD").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  showOnDashboard: boolean("show_on_dashboard").default(false).notNull(),
  
  // Financial Parameters
  initialRevenue: decimal("initial_revenue", { precision: 15, scale: 2 }).notNull(),
  peakRevenue: decimal("peak_revenue", { precision: 15, scale: 2 }).notNull(),
  initialOpexRate: decimal("initial_opex_rate", { precision: 5, scale: 4 }).notNull(),
  matureOpexRate: decimal("mature_opex_rate", { precision: 5, scale: 4 }).notNull(),
  initialCapex: decimal("initial_capex", { precision: 15, scale: 2 }).notNull(),
  maintenanceCapex: decimal("maintenance_capex", { precision: 15, scale: 2 }).notNull(),
  
  // Debt Parameters
  loanAmount: decimal("loan_amount", { precision: 15, scale: 2 }).default("0").notNull(),
  interestRate: decimal("interest_rate", { precision: 5, scale: 4 }).default("0.05").notNull(),
  loanTermYears: integer("loan_term_years").default(10).notNull(),
  paymentFrequency: text("payment_frequency", { enum: ["Monthly", "Quarterly", "Annual"] }).default("Annual").notNull(),
  gracePeriod: integer("grace_period").default(0).notNull(),
  
  // Depreciation Parameters
  assetCost: decimal("asset_cost", { precision: 15, scale: 2 }).default("0").notNull(),
  depreciationMethod: text("depreciation_method", { enum: ["Straight-line", "MACRS-3", "MACRS-5", "MACRS-7", "MACRS-10"] }).default("Straight-line").notNull(),
  depreciationYears: integer("depreciation_years").default(10).notNull(),
  salvageValue: decimal("salvage_value", { precision: 15, scale: 2 }).default("0").notNull(),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
  createdAt: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
