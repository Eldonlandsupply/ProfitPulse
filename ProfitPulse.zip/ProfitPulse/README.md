# Fish Lake Valley Cash Flow Model - Interactive Streamlit Application

## Overview
A comprehensive financial modeling application built with Python and Streamlit that loads Excel cash flow models and provides interactive debt service and depreciation analysis with real-time IRR, NPV, and DSCR calculations.

## Features
- **Excel File Integration**: Automatically loads and parses "Fish Lake Valley cash flow model (MBv1 (1).xlsx"
- **Interactive Debt Modeling**: Configure loan parameters with real-time debt service schedule generation
- **Depreciation Analysis**: Support for straight-line and MACRS depreciation methods
- **Financial Metrics**: Live calculation of IRR, NPV, and Debt Service Coverage Ratios
- **Interactive Charts**: Cash flow waterfalls, debt service breakdowns, and trend analysis
- **Export Functionality**: Download updated models and summary reports

## Installation & Setup

### Prerequisites
- Python 3.11 or higher
- Required packages (automatically installed):
  - streamlit==1.45.1
  - pandas==2.3.0
  - openpyxl==3.1.5
  - numpy==2.3.0
  - plotly==6.1.2
  - matplotlib==3.10.3
  - seaborn==0.13.2

### Running on Replit
1. The application is already configured and running
2. Access the Streamlit interface at: **http://0.0.0.0:8501**
3. The Excel file "Fish_Lake_Valley_Model.xlsx" is automatically loaded

### Running Locally
```bash
# Install dependencies
pip install streamlit pandas openpyxl numpy plotly matplotlib seaborn

# Run the application
streamlit run app.py

# Access at http://localhost:8501
```

## Application Structure

### Sidebar Controls

#### Debt Parameters
- **Loan Amount**: Principal amount ($)
- **Interest Rate**: Annual percentage rate
- **Loan Term**: Duration in years
- **Payment Frequency**: Monthly, Quarterly, or Annual
- **Grace Period**: Interest-only period in years

#### Depreciation Parameters
- **Asset Cost**: Initial asset value ($)
- **Depreciable Life**: Asset useful life in years
- **Salvage Value**: Residual value ($)
- **Method**: Straight-line or MACRS (3, 5, 7, 10-year schedules)

#### Analysis Parameters
- **Discount Rate**: For NPV calculations
- **Initial Investment**: Project startup costs

### Main Dashboard

#### Financial Model Overview
- Base cash flow projections table
- Interactive bar chart showing revenue, expenses, EBITDA, and net cash flow

#### Key Metrics Panel
- **IRR**: Internal Rate of Return percentage
- **NPV**: Net Present Value in dollars
- **Average DSCR**: Debt Service Coverage Ratio
- **DSCR Trend Chart**: Shows coverage ratio over time with minimum threshold line

#### Debt Service Schedule
- Annual debt service summary table
- Detailed payment schedule (expandable)
- Area chart showing interest vs. principal payments over time

#### Depreciation Schedule
- Depreciation expense table by year
- Bar chart visualization of annual depreciation

#### Updated Cash Flow Analysis
- Comprehensive cash flow table including debt service and depreciation
- Waterfall chart showing net cash flow after debt service
- Real-time integration of all financial components

#### Model Assumptions Editor
- Editable data grid for base cash flow assumptions
- Real-time model updates when assumptions change
- Dynamic recalculation of all dependent metrics

### Export Features
- **Excel Export**: Complete model with all schedules in separate sheets
- **Summary Report**: Text-based summary with key parameters and metrics
- **Real-time Updates**: All charts and tables update automatically when parameters change

## Technical Implementation

### Core Classes
- **FinancialModel**: Main model class handling Excel parsing and calculations
- **Debt Schedule Generator**: Handles amortization calculations with grace periods
- **Depreciation Calculator**: Supports multiple depreciation methods including MACRS
- **Financial Metrics**: IRR, NPV, and DSCR calculations

### Calculation Methods
- **IRR**: Newton-Raphson iterative method for accurate rate calculations
- **NPV**: Standard discounted cash flow analysis
- **DSCR**: Earnings before interest, taxes, depreciation, and amortization divided by total debt service
- **MACRS**: IRS Modified Accelerated Cost Recovery System schedules

### Data Flow
1. Excel file parsing and structure identification
2. Base cash flow extraction and validation
3. User parameter input through Streamlit sidebar
4. Real-time debt and depreciation schedule generation
5. Integrated cash flow model updates
6. Dynamic chart and metric recalculation

## Usage Instructions

1. **Load the Application**: Navigate to the Streamlit URL
2. **Configure Debt Parameters**: Use the sidebar to set loan terms
3. **Set Depreciation Options**: Choose asset costs and depreciation methods
4. **Review Results**: Examine updated cash flows, schedules, and metrics
5. **Adjust Parameters**: Make real-time changes and see immediate updates
6. **Export Results**: Download Excel files or summary reports as needed

## Advanced Features

### Interactive Model Editing
- Edit base assumptions directly in the web interface
- Changes propagate through all calculations automatically
- Maintain model integrity with validation checks

### Multiple Depreciation Methods
- Straight-line depreciation for simple assets
- MACRS schedules for tax-compliant depreciation
- Support for 3, 5, 7, and 10-year MACRS lives

### Comprehensive Debt Modeling
- Multiple payment frequencies (monthly, quarterly, annual)
- Grace period support for development phases
- Detailed amortization schedules with principal/interest breakdown

### Visual Analytics
- Interactive Plotly charts with zoom and hover capabilities
- Waterfall charts for cash flow visualization
- Trend analysis for key financial ratios

## File Structure
```
├── app.py                          # Main Streamlit application
├── Fish_Lake_Valley_Model.xlsx     # Source Excel model
├── README.md                       # This documentation
└── Updated_Financial_Model.xlsx    # Generated output (after export)
```

## Support & Troubleshooting

### Common Issues
- **Excel File Not Found**: Ensure "Fish_Lake_Valley_Model.xlsx" is in the root directory
- **Calculation Errors**: Check for negative cash flows or extreme parameter values
- **Chart Display**: Refresh the browser if charts don't render properly

### Performance Notes
- Large models with many years may take longer to process
- Real-time updates occur with each parameter change
- Export operations may take a few seconds for complex models

This application provides a complete financial modeling environment for the Fish Lake Valley project, enabling sophisticated analysis of debt structures, depreciation strategies, and overall project viability through interactive web-based tools.