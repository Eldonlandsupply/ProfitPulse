import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface MonthlyData {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
}

interface FinancialSummary {
  monthlyData: MonthlyData[];
}

export default function ProfitLossChart() {
  const { data: summary, isLoading } = useQuery<FinancialSummary>({
    queryKey: ["/api/financial-summary"],
    refetchInterval: 2000,
    refetchIntervalInBackground: true,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Profit & Loss Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-slate-50 rounded-lg flex items-center justify-center animate-pulse">
            <div className="text-slate-400">Loading chart...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!summary?.monthlyData?.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Profit & Loss Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-slate-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <div className="text-slate-400 mb-2">No data available</div>
              <p className="text-xs text-slate-400">Add some transactions to see the trend</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Profit & Loss Trend</CardTitle>
          <div className="flex items-center space-x-4 text-sm text-slate-600">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-success rounded-full mr-2"></div>
              <span>Revenue</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-danger rounded-full mr-2"></div>
              <span>Expenses</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-primary rounded-full mr-2"></div>
              <span>Profit</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={summary.monthlyData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200" />
              <XAxis 
                dataKey="month" 
                className="text-slate-600"
                fontSize={12}
              />
              <YAxis 
                className="text-slate-600"
                fontSize={12}
                tickFormatter={(value) => `$${value.toLocaleString()}`}
              />
              <Tooltip 
                formatter={(value: number) => [`$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, '']}
                labelFormatter={(label) => `Month: ${label}`}
                contentStyle={{
                  backgroundColor: 'white',
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px',
                  fontSize: '12px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="hsl(142, 76%, 36%)" 
                strokeWidth={2}
                name="Revenue"
                dot={{ fill: 'hsl(142, 76%, 36%)', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="expenses" 
                stroke="hsl(0, 84%, 60%)" 
                strokeWidth={2}
                name="Expenses"
                dot={{ fill: 'hsl(0, 84%, 60%)', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="profit" 
                stroke="hsl(217, 91%, 60%)" 
                strokeWidth={2}
                name="Profit"
                dot={{ fill: 'hsl(217, 91%, 60%)', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
