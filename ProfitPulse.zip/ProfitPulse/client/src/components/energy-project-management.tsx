import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Plus, Edit2, Trash2, Zap, Sun, Wind, Battery, Calculator } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface EnergyProject {
  id: number;
  name: string;
  description: string | null;
  projectType: string;
  timelineYears: number;
  startYear: number;
  currency: string;
  isActive: boolean;
  showOnDashboard: boolean;
  
  // Power Plant Parameters
  plantSizeMW: number;
  ppaOrLease: "PPA" | "Lease";
  ppaRate: number;
  gasPriceMBtu: number;
  capacityFactor: number;
  heatRate: number;
  capExPerKW: number;
  
  // Financial Structure
  debtEquityRatio: number;
  interestRate: string;
  loanTermYears: number;
  taxRate: number;
  discountRate: number;
  
  // O&M Costs
  fixedOMPerKWYear: number;
  variableOMPerMWh: number;
  
  // Solar PV Parameters
  solarEnabled: boolean;
  solarCapacityMW: number;
  solarPPARate: number;
  solarCapacityFactor: number;
  solarCapExPerKW: number;
  solarOMPerKWYear: number;
  solarUsefulLife: number;
  
  // Wind Parameters
  windEnabled: boolean;
  windCapacityMW: number;
  windPPARate: number;
  windCapacityFactor: number;
  windCapExPerKW: number;
  windOMPerKWYear: number;
  windUsefulLife: number;
  
  // Battery Storage Parameters
  batteryEnabled: boolean;
  batteryCapacityMW: number;
  batteryPPARate: number;
  batteryCapacityFactor: number;
  batteryCapExPerKW: number;
  batteryOMPerKWYear: number;
  batteryUsefulLife: number;
  
  // Escalation Parameters
  gasPriceEscalation: number;
  ppaRateEscalation: number;
  omEscalation: number;
  
  createdAt: Date;
  updatedAt: Date;
}

interface EnergyProjectModalProps {
  project?: EnergyProject;
  onClose: () => void;
  isOpen: boolean;
}

function EnergyProjectModal({ project, onClose, isOpen }: EnergyProjectModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    // Basic Project Info
    name: project?.name || "Hybrid Energy Project",
    description: project?.description || "",
    projectType: project?.projectType || "energy",
    timelineYears: project?.timelineYears || 25,
    startYear: project?.startYear || 2024,
    currency: project?.currency || "USD",
    isActive: project?.isActive ?? true,
    showOnDashboard: project?.showOnDashboard ?? false,
    
    // Power Plant Parameters
    plantSizeMW: project?.plantSizeMW || 50,
    ppaOrLease: project?.ppaOrLease || "PPA",
    ppaRate: project?.ppaRate || 75,
    gasPriceMBtu: project?.gasPriceMBtu || 3.5,
    capacityFactor: project?.capacityFactor || 0.60,
    heatRate: project?.heatRate || 7500,
    capExPerKW: project?.capExPerKW || 1200,
    
    // Financial Structure
    debtEquityRatio: project?.debtEquityRatio || 0.70,
    interestRate: project?.interestRate || "0.065",
    loanTermYears: project?.loanTermYears || 15,
    taxRate: project?.taxRate || 0.25,
    discountRate: project?.discountRate || 0.10,
    
    // O&M Costs
    fixedOMPerKWYear: project?.fixedOMPerKWYear || 45,
    variableOMPerMWh: project?.variableOMPerMWh || 3.5,
    
    // Solar PV Parameters
    solarEnabled: project?.solarEnabled ?? false,
    solarCapacityMW: project?.solarCapacityMW || 0,
    solarPPARate: project?.solarPPARate || 45,
    solarCapacityFactor: project?.solarCapacityFactor || 0.25,
    solarCapExPerKW: project?.solarCapExPerKW || 1500,
    solarOMPerKWYear: project?.solarOMPerKWYear || 25,
    solarUsefulLife: project?.solarUsefulLife || 25,
    
    // Wind Parameters
    windEnabled: project?.windEnabled ?? false,
    windCapacityMW: project?.windCapacityMW || 0,
    windPPARate: project?.windPPARate || 55,
    windCapacityFactor: project?.windCapacityFactor || 0.35,
    windCapExPerKW: project?.windCapExPerKW || 1800,
    windOMPerKWYear: project?.windOMPerKWYear || 30,
    windUsefulLife: project?.windUsefulLife || 25,
    
    // Battery Storage Parameters
    batteryEnabled: project?.batteryEnabled ?? false,
    batteryCapacityMW: project?.batteryCapacityMW || 0,
    batteryPPARate: project?.batteryPPARate || 120,
    batteryCapacityFactor: project?.batteryCapacityFactor || 0.20,
    batteryCapExPerKW: project?.batteryCapExPerKW || 2500,
    batteryOMPerKWYear: project?.batteryOMPerKWYear || 40,
    batteryUsefulLife: project?.batteryUsefulLife || 15,
    
    // Escalation Parameters
    gasPriceEscalation: project?.gasPriceEscalation || 0.02,
    ppaRateEscalation: project?.ppaRateEscalation || 0.025,
    omEscalation: project?.omEscalation || 0.03,
    
    // Legacy fields for compatibility
    initialRevenue: project?.initialRevenue || "50000000",
    peakRevenue: project?.peakRevenue || "200000000",
    initialOpexRate: project?.initialOpexRate || "0.55",
    matureOpexRate: project?.matureOpexRate || "0.45",
    initialCapex: project?.initialCapex || "60000000",
    maintenanceCapex: project?.maintenanceCapex || "15000000",
    loanAmount: project?.loanAmount || "75000000",
    paymentFrequency: project?.paymentFrequency || "Annual",
    gracePeriod: project?.gracePeriod || 0,
    assetCost: project?.assetCost || "100000000",
    depreciationMethod: project?.depreciationMethod || "MACRS-15",
    depreciationYears: project?.depreciationYears || 15,
    salvageValue: project?.salvageValue || "10000000",
  });

  const createProjectMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/projects", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Energy project created successfully" });
      onClose();
    },
    onError: () => {
      toast({ title: "Failed to create project", variant: "destructive" });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/projects/${project?.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Energy project updated successfully" });
      onClose();
    },
    onError: () => {
      toast({ title: "Failed to update project", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (project) {
      updateProjectMutation.mutate(formData);
    } else {
      createProjectMutation.mutate(formData);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(amount);
  };

  const calculateMetrics = () => {
    const totalCapacity = formData.plantSizeMW + 
      (formData.solarEnabled ? formData.solarCapacityMW : 0) +
      (formData.windEnabled ? formData.windCapacityMW : 0) +
      (formData.batteryEnabled ? formData.batteryCapacityMW : 0);
    
    const totalCapEx = (formData.plantSizeMW * formData.capExPerKW * 1000) +
      (formData.solarEnabled ? formData.solarCapacityMW * formData.solarCapExPerKW * 1000 : 0) +
      (formData.windEnabled ? formData.windCapacityMW * formData.windCapExPerKW * 1000 : 0) +
      (formData.batteryEnabled ? formData.batteryCapacityMW * formData.batteryCapExPerKW * 1000 : 0);
    
    return { totalCapacity, totalCapEx };
  };

  const metrics = calculateMetrics();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            <span>{project ? "Edit Energy Project" : "Create New Energy Project"}</span>
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="power">Power Plant</TabsTrigger>
              <TabsTrigger value="renewables">Renewables</TabsTrigger>
              <TabsTrigger value="financial">Financial</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            {/* Basic Information Tab */}
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Project Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Hybrid Energy Project"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="projectType">Project Type</Label>
                  <Select 
                    value={formData.projectType} 
                    onValueChange={(value) => setFormData({ ...formData, projectType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="energy">Energy</SelectItem>
                      <SelectItem value="hybrid-gas-renewable">Hybrid Gas-Renewable</SelectItem>
                      <SelectItem value="gas-power">Gas Power Plant</SelectItem>
                      <SelectItem value="renewable">Renewable Energy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Comprehensive hybrid energy project with gas power generation and renewable sources..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="timelineYears">Timeline (Years)</Label>
                  <Input
                    id="timelineYears"
                    type="number"
                    value={formData.timelineYears}
                    onChange={(e) => setFormData({ ...formData, timelineYears: parseInt(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="startYear">Start Year</Label>
                  <Input
                    id="startYear"
                    type="number"
                    value={formData.startYear}
                    onChange={(e) => setFormData({ ...formData, startYear: parseInt(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="currency">Currency</Label>
                  <Select 
                    value={formData.currency} 
                    onValueChange={(value) => setFormData({ ...formData, currency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                      <SelectItem value="GBP">GBP</SelectItem>
                      <SelectItem value="CAD">CAD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Card className="bg-blue-50">
                <CardContent className="pt-4">
                  <h3 className="font-semibold text-blue-800 mb-2">Project Summary</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-blue-600">Total Capacity:</span>
                      <span className="font-medium ml-2">{metrics.totalCapacity.toFixed(1)} MW</span>
                    </div>
                    <div>
                      <span className="text-blue-600">Total CapEx:</span>
                      <span className="font-medium ml-2">{formatCurrency(metrics.totalCapEx)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Power Plant Tab */}
            <TabsContent value="power" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="plantSizeMW">Plant Size (MW)</Label>
                  <Input
                    id="plantSizeMW"
                    type="number"
                    step="0.1"
                    value={formData.plantSizeMW}
                    onChange={(e) => setFormData({ ...formData, plantSizeMW: parseFloat(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="ppaOrLease">Contract Type</Label>
                  <Select 
                    value={formData.ppaOrLease} 
                    onValueChange={(value) => setFormData({ ...formData, ppaOrLease: value as "PPA" | "Lease" })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PPA">Power Purchase Agreement</SelectItem>
                      <SelectItem value="Lease">Lease Agreement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ppaRate">PPA Rate ($/MWh)</Label>
                  <Input
                    id="ppaRate"
                    type="number"
                    step="0.01"
                    value={formData.ppaRate}
                    onChange={(e) => setFormData({ ...formData, ppaRate: parseFloat(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="gasPriceMBtu">Gas Price ($/MMBtu)</Label>
                  <Input
                    id="gasPriceMBtu"
                    type="number"
                    step="0.01"
                    value={formData.gasPriceMBtu}
                    onChange={(e) => setFormData({ ...formData, gasPriceMBtu: parseFloat(e.target.value) })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="capacityFactor">Capacity Factor</Label>
                  <Input
                    id="capacityFactor"
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.capacityFactor}
                    onChange={(e) => setFormData({ ...formData, capacityFactor: parseFloat(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="heatRate">Heat Rate (Btu/kWh)</Label>
                  <Input
                    id="heatRate"
                    type="number"
                    value={formData.heatRate}
                    onChange={(e) => setFormData({ ...formData, heatRate: parseFloat(e.target.value) })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="capExPerKW">CapEx per kW ($)</Label>
                  <Input
                    id="capExPerKW"
                    type="number"
                    value={formData.capExPerKW}
                    onChange={(e) => setFormData({ ...formData, capExPerKW: parseFloat(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="fixedOMPerKWYear">Fixed O&M ($/kW-year)</Label>
                  <Input
                    id="fixedOMPerKWYear"
                    type="number"
                    step="0.01"
                    value={formData.fixedOMPerKWYear}
                    onChange={(e) => setFormData({ ...formData, fixedOMPerKWYear: parseFloat(e.target.value) })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="variableOMPerMWh">Variable O&M ($/MWh)</Label>
                <Input
                  id="variableOMPerMWh"
                  type="number"
                  step="0.01"
                  value={formData.variableOMPerMWh}
                  onChange={(e) => setFormData({ ...formData, variableOMPerMWh: parseFloat(e.target.value) })}
                />
              </div>
            </TabsContent>

            {/* Renewable Sources Tab */}
            <TabsContent value="renewables" className="space-y-6">
              <Accordion type="multiple" className="w-full">
                {/* Solar PV Section */}
                <AccordionItem value="solar">
                  <AccordionTrigger className="text-left">
                    <div className="flex items-center space-x-2">
                      <Sun className="h-5 w-5 text-yellow-500" />
                      <span>Solar PV</span>
                      {formData.solarEnabled && (
                        <span className="text-sm text-green-600 font-medium">
                          ({formData.solarCapacityMW} MW)
                        </span>
                      )}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={formData.solarEnabled}
                        onCheckedChange={(checked) => setFormData({ ...formData, solarEnabled: checked })}
                      />
                      <Label>Enable Solar PV</Label>
                    </div>
                    
                    {formData.solarEnabled && (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="solarCapacityMW">Capacity (MW)</Label>
                            <Input
                              id="solarCapacityMW"
                              type="number"
                              step="0.1"
                              value={formData.solarCapacityMW}
                              onChange={(e) => setFormData({ ...formData, solarCapacityMW: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="solarPPARate">PPA Rate ($/MWh)</Label>
                            <Input
                              id="solarPPARate"
                              type="number"
                              step="0.01"
                              value={formData.solarPPARate}
                              onChange={(e) => setFormData({ ...formData, solarPPARate: parseFloat(e.target.value) })}
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="solarCapacityFactor">Capacity Factor</Label>
                            <Input
                              id="solarCapacityFactor"
                              type="number"
                              step="0.01"
                              min="0"
                              max="1"
                              value={formData.solarCapacityFactor}
                              onChange={(e) => setFormData({ ...formData, solarCapacityFactor: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="solarCapExPerKW">CapEx per kW ($)</Label>
                            <Input
                              id="solarCapExPerKW"
                              type="number"
                              value={formData.solarCapExPerKW}
                              onChange={(e) => setFormData({ ...formData, solarCapExPerKW: parseFloat(e.target.value) })}
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="solarOMPerKWYear">O&M ($/kW-year)</Label>
                            <Input
                              id="solarOMPerKWYear"
                              type="number"
                              step="0.01"
                              value={formData.solarOMPerKWYear}
                              onChange={(e) => setFormData({ ...formData, solarOMPerKWYear: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="solarUsefulLife">Useful Life (years)</Label>
                            <Input
                              id="solarUsefulLife"
                              type="number"
                              value={formData.solarUsefulLife}
                              onChange={(e) => setFormData({ ...formData, solarUsefulLife: parseInt(e.target.value) })}
                            />
                          </div>
                        </div>
                      </>
                    )}
                  </AccordionContent>
                </AccordionItem>

                {/* Wind Section */}
                <AccordionItem value="wind">
                  <AccordionTrigger className="text-left">
                    <div className="flex items-center space-x-2">
                      <Wind className="h-5 w-5 text-blue-500" />
                      <span>Wind Energy</span>
                      {formData.windEnabled && (
                        <span className="text-sm text-green-600 font-medium">
                          ({formData.windCapacityMW} MW)
                        </span>
                      )}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={formData.windEnabled}
                        onCheckedChange={(checked) => setFormData({ ...formData, windEnabled: checked })}
                      />
                      <Label>Enable Wind Energy</Label>
                    </div>
                    
                    {formData.windEnabled && (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="windCapacityMW">Capacity (MW)</Label>
                            <Input
                              id="windCapacityMW"
                              type="number"
                              step="0.1"
                              value={formData.windCapacityMW}
                              onChange={(e) => setFormData({ ...formData, windCapacityMW: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="windPPARate">PPA Rate ($/MWh)</Label>
                            <Input
                              id="windPPARate"
                              type="number"
                              step="0.01"
                              value={formData.windPPARate}
                              onChange={(e) => setFormData({ ...formData, windPPARate: parseFloat(e.target.value) })}
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="windCapacityFactor">Capacity Factor</Label>
                            <Input
                              id="windCapacityFactor"
                              type="number"
                              step="0.01"
                              min="0"
                              max="1"
                              value={formData.windCapacityFactor}
                              onChange={(e) => setFormData({ ...formData, windCapacityFactor: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="windCapExPerKW">CapEx per kW ($)</Label>
                            <Input
                              id="windCapExPerKW"
                              type="number"
                              value={formData.windCapExPerKW}
                              onChange={(e) => setFormData({ ...formData, windCapExPerKW: parseFloat(e.target.value) })}
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="windOMPerKWYear">O&M ($/kW-year)</Label>
                            <Input
                              id="windOMPerKWYear"
                              type="number"
                              step="0.01"
                              value={formData.windOMPerKWYear}
                              onChange={(e) => setFormData({ ...formData, windOMPerKWYear: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="windUsefulLife">Useful Life (years)</Label>
                            <Input
                              id="windUsefulLife"
                              type="number"
                              value={formData.windUsefulLife}
                              onChange={(e) => setFormData({ ...formData, windUsefulLife: parseInt(e.target.value) })}
                            />
                          </div>
                        </div>
                      </>
                    )}
                  </AccordionContent>
                </AccordionItem>

                {/* Battery Storage Section */}
                <AccordionItem value="battery">
                  <AccordionTrigger className="text-left">
                    <div className="flex items-center space-x-2">
                      <Battery className="h-5 w-5 text-green-500" />
                      <span>Battery Storage</span>
                      {formData.batteryEnabled && (
                        <span className="text-sm text-green-600 font-medium">
                          ({formData.batteryCapacityMW} MW)
                        </span>
                      )}
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={formData.batteryEnabled}
                        onCheckedChange={(checked) => setFormData({ ...formData, batteryEnabled: checked })}
                      />
                      <Label>Enable Battery Storage</Label>
                    </div>
                    
                    {formData.batteryEnabled && (
                      <>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="batteryCapacityMW">Capacity (MW)</Label>
                            <Input
                              id="batteryCapacityMW"
                              type="number"
                              step="0.1"
                              value={formData.batteryCapacityMW}
                              onChange={(e) => setFormData({ ...formData, batteryCapacityMW: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="batteryPPARate">PPA Rate ($/MWh)</Label>
                            <Input
                              id="batteryPPARate"
                              type="number"
                              step="0.01"
                              value={formData.batteryPPARate}
                              onChange={(e) => setFormData({ ...formData, batteryPPARate: parseFloat(e.target.value) })}
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="batteryCapacityFactor">Capacity Factor</Label>
                            <Input
                              id="batteryCapacityFactor"
                              type="number"
                              step="0.01"
                              min="0"
                              max="1"
                              value={formData.batteryCapacityFactor}
                              onChange={(e) => setFormData({ ...formData, batteryCapacityFactor: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="batteryCapExPerKW">CapEx per kW ($)</Label>
                            <Input
                              id="batteryCapExPerKW"
                              type="number"
                              value={formData.batteryCapExPerKW}
                              onChange={(e) => setFormData({ ...formData, batteryCapExPerKW: parseFloat(e.target.value) })}
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="batteryOMPerKWYear">O&M ($/kW-year)</Label>
                            <Input
                              id="batteryOMPerKWYear"
                              type="number"
                              step="0.01"
                              value={formData.batteryOMPerKWYear}
                              onChange={(e) => setFormData({ ...formData, batteryOMPerKWYear: parseFloat(e.target.value) })}
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="batteryUsefulLife">Useful Life (years)</Label>
                            <Input
                              id="batteryUsefulLife"
                              type="number"
                              value={formData.batteryUsefulLife}
                              onChange={(e) => setFormData({ ...formData, batteryUsefulLife: parseInt(e.target.value) })}
                            />
                          </div>
                        </div>
                      </>
                    )}
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>

            {/* Financial Parameters Tab */}
            <TabsContent value="financial" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="debtEquityRatio">Debt/Equity Ratio</Label>
                  <Input
                    id="debtEquityRatio"
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.debtEquityRatio}
                    onChange={(e) => setFormData({ ...formData, debtEquityRatio: parseFloat(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="interestRate">Interest Rate</Label>
                  <Input
                    id="interestRate"
                    value={formData.interestRate}
                    onChange={(e) => setFormData({ ...formData, interestRate: e.target.value })}
                    placeholder="0.065"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="taxRate">Tax Rate</Label>
                  <Input
                    id="taxRate"
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.taxRate}
                    onChange={(e) => setFormData({ ...formData, taxRate: parseFloat(e.target.value) })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="discountRate">Discount Rate</Label>
                  <Input
                    id="discountRate"
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.discountRate}
                    onChange={(e) => setFormData({ ...formData, discountRate: parseFloat(e.target.value) })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="loanTermYears">Loan Term (Years)</Label>
                <Input
                  id="loanTermYears"
                  type="number"
                  value={formData.loanTermYears}
                  onChange={(e) => setFormData({ ...formData, loanTermYears: parseInt(e.target.value) })}
                />
              </div>

              <Accordion type="single" collapsible>
                <AccordionItem value="escalation">
                  <AccordionTrigger>Escalation Parameters</AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="gasPriceEscalation">Gas Price Escalation</Label>
                        <Input
                          id="gasPriceEscalation"
                          type="number"
                          step="0.001"
                          value={formData.gasPriceEscalation}
                          onChange={(e) => setFormData({ ...formData, gasPriceEscalation: parseFloat(e.target.value) })}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="ppaRateEscalation">PPA Rate Escalation</Label>
                        <Input
                          id="ppaRateEscalation"
                          type="number"
                          step="0.001"
                          value={formData.ppaRateEscalation}
                          onChange={(e) => setFormData({ ...formData, ppaRateEscalation: parseFloat(e.target.value) })}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="omEscalation">O&M Escalation</Label>
                        <Input
                          id="omEscalation"
                          type="number"
                          step="0.001"
                          value={formData.omEscalation}
                          onChange={(e) => setFormData({ ...formData, omEscalation: parseFloat(e.target.value) })}
                        />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                  />
                  <Label>Active Project</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={formData.showOnDashboard}
                    onCheckedChange={(checked) => setFormData({ ...formData, showOnDashboard: checked })}
                  />
                  <Label>Show on Dashboard</Label>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end space-x-2 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={createProjectMutation.isPending || updateProjectMutation.isPending}
              className="flex items-center space-x-2"
            >
              <Calculator className="h-4 w-4" />
              <span>
                {createProjectMutation.isPending || updateProjectMutation.isPending
                  ? "Saving..." 
                  : project ? "Update Project" : "Create Project"
                }
              </span>
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function EnergyProjectManagement() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<EnergyProject | undefined>();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ["/api/projects"],
  });

  const deleteProjectMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/projects/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Project deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete project", variant: "destructive" });
    },
  });

  const openCreateModal = () => {
    setSelectedProject(undefined);
    setIsModalOpen(true);
  };

  const openEditModal = (project: EnergyProject) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedProject(undefined);
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(parseFloat(amount));
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading energy projects...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center space-x-2">
            <Zap className="h-6 w-6 text-yellow-500" />
            <span>Energy Project Management</span>
          </h2>
          <p className="text-muted-foreground">
            Advanced hybrid gas-power and renewable energy project modeling
          </p>
        </div>
        <Button onClick={openCreateModal} className="flex items-center space-x-2">
          <Plus className="h-4 w-4" />
          <span>Add Energy Project</span>
        </Button>
      </div>

      {projects.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Zap className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No energy projects yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first hybrid energy project with comprehensive financial modeling
            </p>
            <Button onClick={openCreateModal} className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Create Energy Project</span>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(projects as EnergyProject[]).map((project) => (
            <Card key={project.id} className="relative">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <Zap className="h-5 w-5 text-yellow-500" />
                      <span>{project.name}</span>
                    </CardTitle>
                    <CardDescription className="mt-1">
                      {project.description || "No description"}
                    </CardDescription>
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditModal(project)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteProjectMutation.mutate(project.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Type:</span>
                    <span className="text-sm font-medium capitalize">{project.projectType}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Timeline:</span>
                    <span className="text-sm font-medium">
                      {project.startYear} - {project.startYear + project.timelineYears}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Plant Size:</span>
                    <span className="text-sm font-medium">
                      {project.plantSizeMW || 'N/A'} MW
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">PPA Rate:</span>
                    <span className="text-sm font-medium">
                      ${project.ppaRate || 'N/A'}/MWh
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center pt-2 border-t">
                    <span className="text-sm text-muted-foreground">Dashboard:</span>
                    <span className={`text-sm font-medium ${project.showOnDashboard ? 'text-green-600' : 'text-gray-400'}`}>
                      {project.showOnDashboard ? 'Visible' : 'Hidden'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <EnergyProjectModal
        project={selectedProject}
        isOpen={isModalOpen}
        onClose={closeModal}
      />
    </div>
  );
}