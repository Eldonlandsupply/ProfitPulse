import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit2, Trash2, TrendingUp, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Project {
  id: number;
  name: string;
  description: string | null;
  projectType: string;
  timelineYears: number;
  startYear: number;
  currency: string;
  isActive: boolean;
  showOnDashboard: boolean;
  initialRevenue: string;
  peakRevenue: string;
  initialOpexRate: string;
  matureOpexRate: string;
  initialCapex: string;
  maintenanceCapex: string;
  loanAmount: string;
  interestRate: string;
  loanTermYears: number;
  paymentFrequency: string;
  gracePeriod: number;
  assetCost: string;
  depreciationMethod: string;
  depreciationYears: number;
  salvageValue: string;
  createdAt: Date;
  updatedAt: Date;
}

interface ProjectModalProps {
  project?: Project;
  onClose: () => void;
  isOpen: boolean;
}

function ProjectModal({ project, onClose, isOpen }: ProjectModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: project?.name || "",
    description: project?.description || "",
    projectType: project?.projectType || "mining",
    timelineYears: project?.timelineYears || 20,
    startYear: project?.startYear || 2024,
    currency: project?.currency || "USD",
    isActive: project?.isActive ?? true,
    showOnDashboard: project?.showOnDashboard ?? false,
    initialRevenue: project?.initialRevenue || "50000000",
    peakRevenue: project?.peakRevenue || "200000000",
    initialOpexRate: project?.initialOpexRate || "0.70",
    matureOpexRate: project?.matureOpexRate || "0.55",
    initialCapex: project?.initialCapex || "75000000",
    maintenanceCapex: project?.maintenanceCapex || "25000000",
    loanAmount: project?.loanAmount || "0",
    interestRate: project?.interestRate || "0.05",
    loanTermYears: project?.loanTermYears || 10,
    paymentFrequency: project?.paymentFrequency || "Annual",
    gracePeriod: project?.gracePeriod || 0,
    assetCost: project?.assetCost || "0",
    depreciationMethod: project?.depreciationMethod || "Straight-line",
    depreciationYears: project?.depreciationYears || 10,
    salvageValue: project?.salvageValue || "0",
  });

  const createProjectMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/projects", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Project created successfully" });
      onClose();
      setFormData({
        name: "",
        description: "",
        projectType: "mining",
        timelineYears: 20,
        startYear: 2024,
        currency: "USD",
        isActive: true,
        showOnDashboard: false,
        initialRevenue: "50000000",
        peakRevenue: "200000000",
        initialOpexRate: "0.70",
        matureOpexRate: "0.55",
        initialCapex: "75000000",
        maintenanceCapex: "25000000",
        loanAmount: "0",
        interestRate: "0.05",
        loanTermYears: 10,
        paymentFrequency: "Annual",
        gracePeriod: 0,
        assetCost: "0",
        depreciationMethod: "Straight-line",
        depreciationYears: 10,
        salvageValue: "0",
      });
    },
    onError: () => {
      toast({ title: "Failed to create project", variant: "destructive" });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/projects/${project?.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Project updated successfully" });
      onClose();
    },
    onError: () => {
      toast({ title: "Failed to update project", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (project) {
      updateProjectMutation.mutate(formData);
    } else {
      createProjectMutation.mutate(formData);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{project ? "Edit Project" : "Create New Project"}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Project Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Fish Lake Valley Lithium Project"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="projectType">Project Type</Label>
              <Select 
                value={formData.projectType} 
                onValueChange={(value) => setFormData({ ...formData, projectType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mining">Mining</SelectItem>
                  <SelectItem value="energy">Energy</SelectItem>
                  <SelectItem value="real-estate">Real Estate</SelectItem>
                  <SelectItem value="manufacturing">Manufacturing</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Brief description of the project..."
            />
          </div>

          {/* Project Timeline */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="timelineYears">Timeline (Years)</Label>
              <Input
                id="timelineYears"
                type="number"
                value={formData.timelineYears}
                onChange={(e) => setFormData({ ...formData, timelineYears: parseInt(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="startYear">Start Year</Label>
              <Input
                id="startYear"
                type="number"
                value={formData.startYear}
                onChange={(e) => setFormData({ ...formData, startYear: parseInt(e.target.value) })}
              />
            </div>
            
            <div>
              <Label htmlFor="currency">Currency</Label>
              <Select 
                value={formData.currency} 
                onValueChange={(value) => setFormData({ ...formData, currency: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="CAD">CAD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Financial Parameters */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Financial Parameters</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="initialRevenue">Initial Revenue</Label>
                <Input
                  id="initialRevenue"
                  value={formData.initialRevenue}
                  onChange={(e) => setFormData({ ...formData, initialRevenue: e.target.value })}
                  placeholder="50000000"
                />
              </div>
              
              <div>
                <Label htmlFor="peakRevenue">Peak Revenue</Label>
                <Input
                  id="peakRevenue"
                  value={formData.peakRevenue}
                  onChange={(e) => setFormData({ ...formData, peakRevenue: e.target.value })}
                  placeholder="200000000"
                />
              </div>
              
              <div>
                <Label htmlFor="initialOpexRate">Initial OpEx Rate (decimal)</Label>
                <Input
                  id="initialOpexRate"
                  value={formData.initialOpexRate}
                  onChange={(e) => setFormData({ ...formData, initialOpexRate: e.target.value })}
                  placeholder="0.70"
                />
              </div>
              
              <div>
                <Label htmlFor="matureOpexRate">Mature OpEx Rate (decimal)</Label>
                <Input
                  id="matureOpexRate"
                  value={formData.matureOpexRate}
                  onChange={(e) => setFormData({ ...formData, matureOpexRate: e.target.value })}
                  placeholder="0.55"
                />
              </div>
              
              <div>
                <Label htmlFor="initialCapex">Initial CapEx</Label>
                <Input
                  id="initialCapex"
                  value={formData.initialCapex}
                  onChange={(e) => setFormData({ ...formData, initialCapex: e.target.value })}
                  placeholder="75000000"
                />
              </div>
              
              <div>
                <Label htmlFor="maintenanceCapex">Maintenance CapEx</Label>
                <Input
                  id="maintenanceCapex"
                  value={formData.maintenanceCapex}
                  onChange={(e) => setFormData({ ...formData, maintenanceCapex: e.target.value })}
                  placeholder="25000000"
                />
              </div>
            </div>
          </div>

          {/* Settings */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Settings</h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
                <Label>Active Project</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.showOnDashboard}
                  onCheckedChange={(checked) => setFormData({ ...formData, showOnDashboard: checked })}
                />
                <Label>Show on Dashboard</Label>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={createProjectMutation.isPending || updateProjectMutation.isPending}
            >
              {createProjectMutation.isPending || updateProjectMutation.isPending
                ? "Saving..." 
                : project ? "Update Project" : "Create Project"
              }
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function SimpleProjectManagement() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | undefined>();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ["/api/projects"],
  });

  const deleteProjectMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/projects/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Project deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete project", variant: "destructive" });
    },
  });

  const toggleDashboardMutation = useMutation({
    mutationFn: ({ id, showOnDashboard }: { id: number; showOnDashboard: boolean }) =>
      apiRequest("PATCH", `/api/projects/${id}/dashboard`, { showOnDashboard }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({ title: "Dashboard setting updated" });
    },
    onError: () => {
      toast({ title: "Failed to update dashboard setting", variant: "destructive" });
    },
  });

  const openCreateModal = () => {
    setSelectedProject(undefined);
    setIsModalOpen(true);
  };

  const openEditModal = (project: Project) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedProject(undefined);
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      notation: 'compact',
      maximumFractionDigits: 1,
    }).format(parseFloat(amount));
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading projects...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Project Management</h2>
          <p className="text-muted-foreground">
            Manage your financial modeling projects with comprehensive parameters
          </p>
        </div>
        <Button onClick={openCreateModal}>
          <Plus className="mr-2 h-4 w-4" />
          Add Project
        </Button>
      </div>

      {projects.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <TrendingUp className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No projects yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first financial modeling project to get started
            </p>
            <Button onClick={openCreateModal}>
              <Plus className="mr-2 h-4 w-4" />
              Create Project
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project: Project) => (
            <Card key={project.id} className="relative">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <CardDescription className="mt-1">
                      {project.description || "No description"}
                    </CardDescription>
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditModal(project)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteProjectMutation.mutate(project.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Type:</span>
                    <Badge variant="secondary">{project.projectType}</Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Timeline:</span>
                    <span className="text-sm font-medium">
                      {project.startYear} - {project.startYear + project.timelineYears}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Peak Revenue:</span>
                    <span className="text-sm font-medium">
                      {formatCurrency(project.peakRevenue)}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Initial CapEx:</span>
                    <span className="text-sm font-medium">
                      {formatCurrency(project.initialCapex)}
                    </span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Status:</span>
                    <Badge variant={project.isActive ? "default" : "secondary"}>
                      {project.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center pt-2 border-t">
                    <span className="text-sm text-muted-foreground">Show on Dashboard:</span>
                    <Switch
                      checked={project.showOnDashboard}
                      onCheckedChange={(checked) =>
                        toggleDashboardMutation.mutate({
                          id: project.id,
                          showOnDashboard: checked,
                        })
                      }
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <ProjectModal
        project={selectedProject}
        isOpen={isModalOpen}
        onClose={closeModal}
      />
    </div>
  );
}