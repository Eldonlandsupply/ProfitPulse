import { BarChart3, Home, Receipt, Tags, TrendingUp, FolderOpen, Zap, Clock } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Sidebar() {
  const [location] = useLocation();

  const navigation = [
    { name: "Dashboard", href: "/", icon: Home, current: location === "/" || location === "/dashboard" },
    { name: "Projects", href: "/projects", icon: FolderOpen, current: location === "/projects" },
    { name: "Energy Projects", href: "/energy-projects", icon: Zap, current: location === "/energy-projects" },
    { name: "Countdown Timer", href: "/countdown", icon: Clock, current: location === "/countdown" },
    { name: "Transactions", href: "/transactions", icon: Receipt, current: location === "/transactions" },
    { name: "Categories", href: "/categories", icon: Tags, current: location === "/categories" },
    { name: "Reports", href: "/reports", icon: BarChart3, current: location === "/reports" },
  ];

  return (
    <div className="hidden lg:flex lg:w-64 lg:flex-col">
      <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto bg-white border-r border-slate-200">
        {/* Logo */}
        <div className="flex items-center flex-shrink-0 px-6">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-white" />
            </div>
            <span className="ml-3 text-xl font-semibold text-slate-900">P&L Manager</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mt-8 flex-grow">
          <div className="px-3 space-y-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`${
                  item.current
                    ? "bg-primary text-white"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                } group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors`}
              >
                <item.icon className="mr-3 h-4 w-4" />
                {item.name}
              </Link>
            ))}
          </div>
        </nav>

        {/* User profile */}
        <div className="px-3 mt-auto">
          <div className="flex items-center px-3 py-3 bg-slate-50 rounded-lg">
            <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center">
              <span className="text-slate-600 text-sm font-medium">JD</span>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-slate-900">John Doe</p>
              <p className="text-xs text-slate-500">Financial Manager</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
