import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator, Download, RefreshCw } from "lucide-react";

interface CapExCategory {
  category: string;
  unitCost: number;
  capacity: number;
  totalCost: number;
  percentage: number;
}

export default function CapExBreakdownCalculator() {
  const [capacity, setCapacity] = useState(100000); // Default 100 MW = 100,000 kW
  
  const defaultCategories: Omit<CapExCategory, 'totalCost' | 'percentage'>[] = [
    { category: "Land Acquisition", unitCost: 25, capacity: capacity },
    { category: "Engineering & Design", unitCost: 120, capacity: capacity },
    { category: "Equipment Manufacturing", unitCost: 650, capacity: capacity },
    { category: "Procurement", unitCost: 45, capacity: capacity },
    { category: "EPC Installation", unitCost: 320, capacity: capacity },
    { category: "Commissioning", unitCost: 40, capacity: capacity }
  ];

  const [categories, setCategories] = useState(defaultCategories);

  const calculateBreakdown = (): CapExCategory[] => {
    const calculatedCategories = categories.map(cat => ({
      ...cat,
      capacity: capacity,
      totalCost: cat.unitCost * capacity
    }));

    const totalCapEx = calculatedCategories.reduce((sum, cat) => sum + cat.totalCost, 0);

    return calculatedCategories.map(cat => ({
      ...cat,
      percentage: totalCapEx > 0 ? (cat.totalCost / totalCapEx) * 100 : 0
    }));
  };

  const breakdown = calculateBreakdown();
  const totalCapEx = breakdown.reduce((sum, cat) => sum + cat.totalCost, 0);
  const totalUnitCost = totalCapEx / capacity;

  const updateUnitCost = (index: number, newUnitCost: number) => {
    const updatedCategories = [...categories];
    updatedCategories[index] = { ...updatedCategories[index], unitCost: newUnitCost };
    setCategories(updatedCategories);
  };

  const resetToDefaults = () => {
    setCapacity(100000);
    setCategories(defaultCategories);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage.toFixed(1)}%`;
  };

  const exportToCSV = () => {
    const headers = ['Category', 'Unit Cost ($/kW)', 'Capacity (kW)', 'Total Cost ($)', '% of Total'];
    const rows = breakdown.map(cat => [
      cat.category,
      cat.unitCost.toString(),
      cat.capacity.toString(),
      cat.totalCost.toString(),
      (cat.percentage / 100).toString()
    ]);
    
    // Add totals row
    rows.push([
      'Total CapEx',
      totalUnitCost.toFixed(0),
      capacity.toString(),
      totalCapEx.toString(),
      '1.00'
    ]);

    const csvContent = [headers, ...rows]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'capex-breakdown.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calculator className="h-5 w-5 text-blue-500" />
            <span>CapEx Breakdown Calculator</span>
          </CardTitle>
          <CardDescription>
            Detailed capital expenditure analysis with cost breakdowns by category
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Capacity Input */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-blue-50 rounded-lg">
            <div>
              <Label htmlFor="capacity">Total Capacity (kW)</Label>
              <Input
                id="capacity"
                type="number"
                value={capacity}
                onChange={(e) => setCapacity(parseInt(e.target.value) || 0)}
                className="bg-white"
              />
            </div>
            <div>
              <Label>Total Project Capacity</Label>
              <div className="text-lg font-semibold text-blue-700">
                {(capacity / 1000).toFixed(0)} MW
              </div>
            </div>
            <div>
              <Label>Total CapEx</Label>
              <div className="text-lg font-semibold text-green-700">
                {formatCurrency(totalCapEx)}
              </div>
            </div>
          </div>

          {/* CapEx Breakdown Table */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-4 py-2 text-left font-semibold">Category</th>
                  <th className="border border-gray-300 px-4 py-2 text-right font-semibold">Unit Cost ($/kW)</th>
                  <th className="border border-gray-300 px-4 py-2 text-right font-semibold">Capacity (kW)</th>
                  <th className="border border-gray-300 px-4 py-2 text-right font-semibold">Total Cost ($)</th>
                  <th className="border border-gray-300 px-4 py-2 text-right font-semibold">% of Total</th>
                </tr>
              </thead>
              <tbody>
                {breakdown.map((cat, index) => (
                  <tr key={cat.category} className="hover:bg-gray-50">
                    <td className="border border-gray-300 px-4 py-2 font-medium">{cat.category}</td>
                    <td className="border border-gray-300 px-4 py-2 text-right">
                      <Input
                        type="number"
                        value={cat.unitCost}
                        onChange={(e) => updateUnitCost(index, parseFloat(e.target.value) || 0)}
                        className="w-20 text-right text-sm"
                        step="0.01"
                      />
                    </td>
                    <td className="border border-gray-300 px-4 py-2 text-right">
                      {cat.capacity.toLocaleString()}
                    </td>
                    <td className="border border-gray-300 px-4 py-2 text-right font-medium">
                      {formatCurrency(cat.totalCost)}
                    </td>
                    <td className="border border-gray-300 px-4 py-2 text-right">
                      {formatPercentage(cat.percentage)}
                    </td>
                  </tr>
                ))}
                {/* Totals Row */}
                <tr className="bg-blue-100 font-bold">
                  <td className="border border-gray-300 px-4 py-2">Total CapEx</td>
                  <td className="border border-gray-300 px-4 py-2 text-right">
                    ${totalUnitCost.toFixed(0)}
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-right">
                    {capacity.toLocaleString()}
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-right">
                    {formatCurrency(totalCapEx)}
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-right">
                    100.0%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between items-center pt-4">
            <Button variant="outline" onClick={resetToDefaults} className="flex items-center space-x-2">
              <RefreshCw className="h-4 w-4" />
              <span>Reset to Defaults</span>
            </Button>
            
            <Button onClick={exportToCSV} className="flex items-center space-x-2">
              <Download className="h-4 w-4" />
              <span>Export CSV</span>
            </Button>
          </div>

          {/* Summary Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t">
            <Card>
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Average Unit Cost</div>
                <div className="text-lg font-semibold">${totalUnitCost.toFixed(0)}/kW</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Largest Category</div>
                <div className="text-lg font-semibold">
                  {breakdown.length > 0 ? 
                    breakdown.reduce((max, cat) => cat.totalCost > max.totalCost ? cat : max).category 
                    : 'N/A'
                  }
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Equipment %</div>
                <div className="text-lg font-semibold">
                  {breakdown.find(cat => cat.category === "Equipment Manufacturing")?.percentage.toFixed(1) || '0'}%
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">EPC Installation %</div>
                <div className="text-lg font-semibold">
                  {breakdown.find(cat => cat.category === "EPC Installation")?.percentage.toFixed(1) || '0'}%
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}