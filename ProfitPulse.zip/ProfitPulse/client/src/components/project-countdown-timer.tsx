import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Clock, Calendar, User, Mail, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CountdownProject {
  id: string;
  name: string;
  deadline: string;
  owner: string;
  ownerEmail?: string;
  showOnDashboard?: boolean;
}

export default function ProjectCountdownTimer() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({
    name: '',
    deadline: '',
    owner: '',
    ownerEmail: ''
  });

  // Current time ticker
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 60000); // Update every minute
    return () => clearInterval(interval);
  }, []);

  // Fetch countdown projects
  const { data: projects = [], isLoading } = useQuery<CountdownProject[]>({
    queryKey: ['/api/countdown-projects'],
  });

  // Add new countdown project
  const addProjectMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/countdown-projects", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/countdown-projects'] });
      setForm({ name: '', deadline: '', owner: '', ownerEmail: '' });
      toast({ title: "Countdown project added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add countdown project", variant: "destructive" });
    },
  });

  // Toggle dashboard display
  const toggleDashboardMutation = useMutation({
    mutationFn: ({ id, showOnDashboard }: { id: string; showOnDashboard: boolean }) => 
      apiRequest("PUT", `/api/countdown-projects/${id}/dashboard`, { showOnDashboard }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/countdown-projects'] });
    },
    onError: () => {
      toast({ title: "Failed to update dashboard setting", variant: "destructive" });
    },
  });

  const toggleDashboard = (id: string) => {
    const project = projects.find((p) => p.id === id);
    if (project) {
      toggleDashboardMutation.mutate({ 
        id, 
        showOnDashboard: !project.showOnDashboard 
      });
    }
  };

  // Calculate days left
  const daysLeft = (deadline: string) => {
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  // Get status color based on days left
  const getStatusColor = (days: number) => {
    if (days < 0) return "text-red-600 bg-red-50";
    if (days === 0) return "text-orange-600 bg-orange-50";
    if (days <= 2) return "text-yellow-600 bg-yellow-50";
    if (days <= 5) return "text-blue-600 bg-blue-50";
    return "text-green-600 bg-green-50";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addProjectMutation.mutate(form);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center">
            <Clock className="h-6 w-6 animate-spin mr-2" />
            <span>Loading countdown projects...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Add New Countdown Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-blue-500" />
            <span>New Countdown</span>
          </CardTitle>
          <CardDescription>
            Add project deadlines with automated email reminders
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Project Name</Label>
              <Input
                id="name"
                type="text"
                required
                placeholder="Project Name"
                value={form.name}
                onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))}
              />
            </div>
            
            <div>
              <Label htmlFor="deadline">Deadline</Label>
              <Input
                id="deadline"
                type="date"
                required
                value={form.deadline}
                onChange={(e) => setForm(f => ({ ...f, deadline: e.target.value }))}
              />
            </div>
            
            <div>
              <Label htmlFor="owner">Owner Name</Label>
              <Input
                id="owner"
                type="text"
                required
                placeholder="Owner Name"
                value={form.owner}
                onChange={(e) => setForm(f => ({ ...f, owner: e.target.value }))}
              />
            </div>
            
            <div>
              <Label htmlFor="ownerEmail">Owner Email (optional)</Label>
              <Input
                id="ownerEmail"
                type="email"
                placeholder="Owner Email (for reminders)"
                value={form.ownerEmail}
                onChange={(e) => setForm(f => ({ ...f, ownerEmail: e.target.value }))}
              />
            </div>
            
            <Button
              type="submit"
              disabled={addProjectMutation.isPending}
              className="w-full flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>
                {addProjectMutation.isPending ? "Adding..." : "Add Project"}
              </span>
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Countdown List */}
      <div className="space-y-4">
        {projects.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <Clock className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No countdown projects yet</h3>
              <p className="text-muted-foreground">
                Add your first project deadline to start tracking time and receive reminders
              </p>
            </CardContent>
          </Card>
        ) : (
          projects.map((project: CountdownProject) => {
            const days = daysLeft(project.deadline);
            const statusColor = getStatusColor(days);
            
            return (
              <Card key={project.id} className={`border-l-4 ${statusColor}`}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div className="space-y-2">
                      <h4 className="font-medium text-lg">{project.name}</h4>
                      
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>{project.owner}</span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(project.deadline).toLocaleDateString()}</span>
                        </div>
                        
                        {project.ownerEmail && (
                          <div className="flex items-center space-x-1">
                            <Mail className="h-4 w-4" />
                            <span>{project.ownerEmail}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right space-y-2">
                      <div className={`text-3xl font-bold ${statusColor}`}>
                        {days >= 0 ? `${days}d` : `-${Math.abs(days)}d`}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {days < 0 ? "Overdue" : days === 0 ? "Due Today" : "Days Left"}
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => toggleDashboard(project.id)}
                        className="text-xs"
                      >
                        {project.showOnDashboard ? "Remove from Dashboard" : "Add to Dashboard"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
      
      {/* Email Reminder Info */}
      {projects.length > 0 && (
        <Card className="bg-blue-50">
          <CardContent className="pt-4">
            <div className="flex items-start space-x-2">
              <Mail className="h-5 w-5 text-blue-500 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-800">Automated Email Reminders</h4>
                <p className="text-sm text-blue-600 mt-1">
                  Email reminders will be sent automatically at 10, 5, 2, and 0 days before each deadline 
                  to project owners with email addresses.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}