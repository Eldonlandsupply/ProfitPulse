import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface CategoryData {
  id: number;
  name: string;
  type: string;
  color: string;
  total: number;
  percentage: number;
}

interface FinancialSummary {
  categoryBreakdown: CategoryData[];
  totalExpenses: number;
}

export default function CategoryBreakdown() {
  const { data: summary, isLoading } = useQuery<FinancialSummary>({
    queryKey: ["/api/financial-summary"],
    refetchInterval: 2000,
    refetchIntervalInBackground: true,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Top Expense Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-8 bg-slate-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const expenseCategories = summary?.categoryBreakdown
    ?.filter(cat => cat.type === "expense" && cat.total > 0)
    ?.sort((a, b) => b.total - a.total)
    ?.slice(0, 5) || [];

  if (!expenseCategories.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Top Expense Categories</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-slate-500 py-8">
            <p>No expense data available</p>
            <p className="text-xs mt-1">Add some expense transactions to see the breakdown</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Top Expense Categories</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {expenseCategories.map((category) => (
            <div key={category.id} className="flex items-center justify-between">
              <div className="flex items-center">
                <div 
                  className="w-3 h-3 rounded-full mr-3"
                  style={{ backgroundColor: category.color }}
                ></div>
                <span className="text-sm text-slate-700">{category.name}</span>
              </div>
              <div className="text-right">
                <span className="text-sm font-medium text-slate-900">
                  ${category.total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <div className="text-xs text-slate-500">
                  {category.percentage.toFixed(1)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
