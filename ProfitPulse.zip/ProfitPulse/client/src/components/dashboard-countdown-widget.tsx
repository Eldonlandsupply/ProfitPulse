import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Calendar, User } from "lucide-react";
import { useState, useEffect } from "react";

interface CountdownProject {
  id: string;
  name: string;
  deadline: string;
  owner: string;
  ownerEmail?: string;
  showOnDashboard?: boolean;
}

export default function DashboardCountdownWidget() {
  const [now, setNow] = useState(new Date());
  
  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(interval);
  }, []);

  const { data: projects = [] } = useQuery<CountdownProject[]>({
    queryKey: ['/api/countdown-projects'],
  });

  const dashboardProjects = projects.filter((p) => p.showOnDashboard);

  const daysLeft = (deadline: string) => {
    const deadlineDate = new Date(deadline);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    deadlineDate.setHours(0, 0, 0, 0);
    const diffTime = deadlineDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const getStatusColor = (days: number) => {
    if (days < 0) return "text-red-600 border-red-200";
    if (days === 0) return "text-red-500 border-red-200";
    if (days <= 2) return "text-orange-500 border-orange-200";
    if (days <= 5) return "text-yellow-500 border-yellow-200";
    return "text-green-600 border-green-200";
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center">
          <Clock className="h-5 w-5 mr-2" />
          Project Deadlines
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {dashboardProjects.length === 0 ? (
          <div className="text-center py-4 text-muted-foreground">
            <Clock className="mx-auto h-8 w-8 mb-2 opacity-50" />
            <p className="text-sm">No countdown projects added to dashboard</p>
            <p className="text-xs mt-1">Add projects from the Countdown Timer page</p>
          </div>
        ) : (
          dashboardProjects.map((project) => {
            const days = daysLeft(project.deadline);
            const statusColor = getStatusColor(days);
            
            return (
              <div key={project.id} className={`p-3 rounded-lg border-l-4 bg-slate-50 ${statusColor}`}>
                <div className="flex justify-between items-center">
                  <div className="space-y-1">
                    <h4 className="font-medium text-sm">{project.name}</h4>
                    <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <User className="h-3 w-3" />
                        <span>{project.owner}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-3 w-3" />
                        <span>{new Date(project.deadline).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-xl font-bold ${statusColor}`}>
                      {days >= 0 ? `${days}d` : `-${Math.abs(days)}d`}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {days < 0 ? "Overdue" : days === 0 ? "Due Today" : "Days Left"}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}