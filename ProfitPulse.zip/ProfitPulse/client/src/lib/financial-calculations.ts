import type { Transaction } from "@shared/schema";

export interface FinancialMetrics {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  profitMargin: number;
}

export interface MonthlyData {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
}

export function calculateFinancialMetrics(transactions: Transaction[]): FinancialMetrics {
  const totalRevenue = transactions
    .filter(t => t.type === "income")
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);
  
  const totalExpenses = transactions
    .filter(t => t.type === "expense")
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);
  
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  return {
    totalRevenue,
    totalExpenses,
    netProfit,
    profitMargin,
  };
}

export function generateMonthlyData(transactions: Transaction[], months: number = 6): MonthlyData[] {
  const now = new Date();
  const monthlyData: MonthlyData[] = [];

  for (let i = months - 1; i >= 0; i--) {
    const month = new Date();
    month.setMonth(now.getMonth() - i);
    const monthStr = month.toISOString().slice(0, 7); // YYYY-MM format

    const monthTransactions = transactions.filter(t => 
      t.date.startsWith(monthStr)
    );

    const revenue = monthTransactions
      .filter(t => t.type === "income")
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    const expenses = monthTransactions
      .filter(t => t.type === "expense")
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    monthlyData.push({
      month: month.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      revenue,
      expenses,
      profit: revenue - expenses
    });
  }

  return monthlyData;
}

export function calculateCategoryTotals(transactions: Transaction[], categories: any[]) {
  return categories.map(category => {
    const categoryTransactions = transactions.filter(t => t.category === category.name);
    const total = categoryTransactions.reduce((sum, t) => sum + parseFloat(t.amount), 0);
    
    // Calculate percentage based on type
    const totalForType = transactions
      .filter(t => t.type === category.type)
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    
    const percentage = totalForType > 0 ? (total / totalForType) * 100 : 0;

    return {
      ...category,
      total,
      percentage
    };
  }).filter(c => c.total > 0);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatPercentage(percentage: number): string {
  return `${percentage.toFixed(1)}%`;
}
