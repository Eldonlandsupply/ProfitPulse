import { useState } from "react";
import Sidebar from "@/components/sidebar";
import CategoryManagement from "@/components/category-management";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";

export default function CategoriesPage() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar for desktop */}
      <div className="hidden md:flex">
        <Sidebar />
      </div>

      {/* Mobile sidebar */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-gray-800 bg-opacity-50">
          <div className="w-64 bg-white h-full">
            <Sidebar />
            <Button
              variant="ghost"
              className="absolute top-4 right-4"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              ×
            </Button>
          </div>
        </div>
      )}

      {/* Main content area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header */}
        <div className="md:hidden flex items-center justify-between p-4 bg-white border-b">
          <h1 className="text-xl font-semibold">Categories</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6">
          <CategoryManagement />
        </main>
      </div>
    </div>
  );
}