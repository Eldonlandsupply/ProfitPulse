import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import SummaryCards from "@/components/summary-cards";
import ProfitLossChart from "@/components/profit-loss-chart";
import CategoryBreakdown from "@/components/category-breakdown";
import RecentTransactions from "@/components/recent-transactions";
import TransactionModal from "@/components/transaction-modal";
import EmployeeManagement from "@/components/employee-management";
import ExcelUpload from "@/components/excel-upload";
import ProjectCountdownTimer from "@/components/project-countdown-timer";
import DashboardCountdownWidget from "@/components/dashboard-countdown-widget";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Menu, RotateCcw, Edit3, Save, GripVertical } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DashboardWidget {
  id: string;
  component: string;
  position: number;
  size: 'small' | 'medium' | 'large';
  visible: boolean;
}

export default function Dashboard() {
  const { toast } = useToast();
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState("current-month");
  const [isEditMode, setIsEditMode] = useState(false);
  const [dashboardLayout, setDashboardLayout] = useState<DashboardWidget[]>([
    { id: 'summary-cards', component: 'SummaryCards', position: 0, size: 'large', visible: true },
    { id: 'profit-loss-chart', component: 'ProfitLossChart', position: 1, size: 'large', visible: true },
    { id: 'category-breakdown', component: 'CategoryBreakdown', position: 2, size: 'medium', visible: true },
    { id: 'countdown-widget', component: 'DashboardCountdownWidget', position: 3, size: 'large', visible: true },
    { id: 'employee-management', component: 'EmployeeManagement', position: 4, size: 'medium', visible: true },
    { id: 'excel-upload', component: 'ExcelUpload', position: 5, size: 'medium', visible: true },
    { id: 'recent-transactions', component: 'RecentTransactions', position: 6, size: 'large', visible: true },
  ]);

  const resetMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/reset"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/financial-summary"] });
      toast({
        title: "Data Reset",
        description: "All transactions and employees have been cleared",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reset data",
        variant: "destructive",
      });
    },
  });

  const handleReset = () => {
    if (confirm("Are you sure you want to reset all data? This will delete all transactions and employees permanently.")) {
      resetMutation.mutate();
    }
  };

  const moveWidget = (dragIndex: number, hoverIndex: number) => {
    const draggedWidget = dashboardLayout[dragIndex];
    const newLayout = [...dashboardLayout];
    newLayout.splice(dragIndex, 1);
    newLayout.splice(hoverIndex, 0, draggedWidget);
    
    // Update positions
    const updatedLayout = newLayout.map((widget, index) => ({
      ...widget,
      position: index
    }));
    
    setDashboardLayout(updatedLayout);
  };

  const toggleWidgetVisibility = (id: string) => {
    setDashboardLayout(prev => 
      prev.map(widget => 
        widget.id === id ? { ...widget, visible: !widget.visible } : widget
      )
    );
  };

  const saveDashboardLayout = () => {
    localStorage.setItem('dashboardLayout', JSON.stringify(dashboardLayout));
    setIsEditMode(false);
    toast({
      title: "Dashboard Saved",
      description: "Your dashboard layout has been saved successfully",
    });
  };

  const loadDashboardLayout = () => {
    const saved = localStorage.getItem('dashboardLayout');
    if (saved) {
      try {
        const parsedLayout = JSON.parse(saved);
        setDashboardLayout(parsedLayout);
      } catch (error) {
        console.error('Failed to load dashboard layout:', error);
      }
    }
  };

  // Load saved layout on component mount
  useEffect(() => {
    const saved = localStorage.getItem('dashboardLayout');
    if (saved) {
      try {
        const parsedLayout = JSON.parse(saved);
        setDashboardLayout(parsedLayout);
      } catch (error) {
        console.error('Failed to load dashboard layout:', error);
      }
    }
  }, []);

  const renderWidget = (widget: DashboardWidget, index: number) => {
    if (!widget.visible) return null;
    
    const handleDragStart = (e: React.DragEvent) => {
      e.dataTransfer.setData('text/plain', index.toString());
    };
    
    const handleDragOver = (e: React.DragEvent) => {
      e.preventDefault();
    };
    
    const handleDrop = (e: React.DragEvent) => {
      e.preventDefault();
      const dragIndex = parseInt(e.dataTransfer.getData('text/plain'));
      const hoverIndex = index;
      if (dragIndex !== hoverIndex) {
        moveWidget(dragIndex, hoverIndex);
      }
    };
    
    const widgetProps = {
      draggable: isEditMode,
      onDragStart: handleDragStart,
      onDragOver: handleDragOver,
      onDrop: handleDrop,
      className: `relative ${isEditMode ? 'border-2 border-dashed border-blue-300 cursor-move' : ''}`
    };
    
    const renderGrip = () => {
      if (!isEditMode) return null;
      return (
        <div className="absolute top-2 right-2 z-10 p-1 bg-blue-100 rounded cursor-move">
          <GripVertical className="h-4 w-4 text-blue-600" />
        </div>
      );
    };
    
    switch (widget.component) {
      case 'SummaryCards':
        return (
          <div key={widget.id} {...widgetProps}>
            {renderGrip()}
            <SummaryCards />
          </div>
        );
      case 'ProfitLossChart':
        return (
          <div key={widget.id} {...widgetProps}>
            {renderGrip()}
            <ProfitLossChart />
          </div>
        );
      case 'CategoryBreakdown':
        return (
          <div key={widget.id} {...widgetProps}>
            {renderGrip()}
            <CategoryBreakdown />
          </div>
        );
      case 'DashboardCountdownWidget':
        return (
          <div key={widget.id} {...widgetProps}>
            {renderGrip()}
            <DashboardCountdownWidget />
          </div>
        );
      case 'EmployeeManagement':
        return (
          <div key={widget.id} {...widgetProps}>
            {renderGrip()}
            <EmployeeManagement />
          </div>
        );
      case 'ExcelUpload':
        return (
          <div key={widget.id} {...widgetProps}>
            {renderGrip()}
            <ExcelUpload />
          </div>
        );
      case 'RecentTransactions':
        return (
          <div key={widget.id} {...widgetProps}>
            {renderGrip()}
            <RecentTransactions />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Mobile menu overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 transition-transform duration-300 ease-in-out`}>
        <Sidebar />
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Mobile nav toggle */}
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 py-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>

        {/* Top bar */}
        <header className="bg-white border-b border-slate-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-slate-900">Dashboard</h1>
              <p className="text-sm text-slate-500 mt-1">Overview of your financial performance</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <label className="text-sm text-slate-600">Period:</label>
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="current-month">Current Month</SelectItem>
                    <SelectItem value="last-month">Last Month</SelectItem>
                    <SelectItem value="current-quarter">Current Quarter</SelectItem>
                    <SelectItem value="current-year">Current Year</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {isEditMode ? (
                <Button 
                  onClick={saveDashboardLayout}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save Layout
                </Button>
              ) : (
                <Button 
                  onClick={() => setIsEditMode(true)}
                  variant="outline"
                  className="text-slate-600 hover:text-slate-900"
                >
                  <Edit3 className="h-4 w-4 mr-2" />
                  Edit Dashboard
                </Button>
              )}
              <Button 
                onClick={handleReset}
                variant="outline"
                disabled={resetMutation.isPending}
                className="text-slate-600 hover:text-slate-900"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                {resetMutation.isPending ? "Resetting..." : "Reset Data"}
              </Button>
              <Button 
                onClick={() => setIsTransactionModalOpen(true)}
                className="bg-primary hover:bg-blue-700 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Transaction
              </Button>
            </div>
          </div>
        </header>

        {/* Dashboard content */}
        <main className="flex-1 overflow-y-auto p-6">
          {isEditMode && (
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h3 className="text-sm font-medium text-blue-800 mb-2">Edit Mode Active</h3>
              <p className="text-xs text-blue-600">
                Drag and drop widgets to reorder them. Click the grip icon (⋮⋮) to move widgets around.
                Click "Save Layout" when you're done to save your changes.
              </p>
            </div>
          )}
          
          <div className="space-y-6">
            {dashboardLayout
              .sort((a, b) => a.position - b.position)
              .map((widget, index) => renderWidget(widget, index))
            }
          </div>
        </main>
      </div>

      {/* Transaction Modal */}
      <TransactionModal 
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
      />
    </div>
  );
}
