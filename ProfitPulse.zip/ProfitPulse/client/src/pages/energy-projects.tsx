import EnergyProjectManagement from "@/components/energy-project-management";

export default function EnergyProjects() {
  return (
    <div className="container mx-auto py-6">
      <EnergyProjectManagement />
    </div>
  );
}