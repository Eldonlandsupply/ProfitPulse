import { useState } from "react";
import Sidebar from "@/components/sidebar";
import SimpleProjectManagement from "@/components/simple-project-management";
import CapExBreakdownCalculator from "@/components/capex-breakdown-calculator";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Menu } from "lucide-react";

export default function ProjectsPage() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Mobile menu overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 transition-transform duration-300 ease-in-out`}>
        <Sidebar />
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Mobile nav toggle */}
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 py-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Tabs defaultValue="projects" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="projects">Project Management</TabsTrigger>
              <TabsTrigger value="capex">CapEx Calculator</TabsTrigger>
            </TabsList>
            
            <TabsContent value="projects" className="mt-6">
              <SimpleProjectManagement />
            </TabsContent>
            
            <TabsContent value="capex" className="mt-6">
              <CapExBreakdownCalculator />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}